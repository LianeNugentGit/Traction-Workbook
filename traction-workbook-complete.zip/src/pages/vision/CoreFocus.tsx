import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { visionDb } from '../../lib/supabase';
import { 
  Button, 
  Container, 
  Typography, 
  Box, 
  Grid, 
  TextField, 
  IconButton, 
  Paper,
  Divider,
  Alert,
  Snackbar
} from '@mui/material';
import SaveIcon from '@mui/icons-material/Save';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import AICoachingPanel from '../../components/AICoachingPanel';

const CoreFocus = () => {
  const { companyId } = useParams<{ companyId: string }>();
  const navigate = useNavigate();
  
  const [coreFocus, setCoreFocus] = useState<any>({
    purpose: '',
    niche: ''
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showCoaching, setShowCoaching] = useState(false);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'success' });
  
  useEffect(() => {
    if (companyId) {
      fetchCoreFocus();
    }
  }, [companyId]);
  
  const fetchCoreFocus = async () => {
    setLoading(true);
    try {
      const { data, error } = await visionDb.getCoreFocus(companyId as string);
      
      if (error) {
        if (error.code === 'PGRST116') {
          // No data found, this is fine for a new company
          setCoreFocus({
            purpose: '',
            niche: ''
          });
        } else {
          throw error;
        }
      } else if (data) {
        setCoreFocus(data);
      }
    } catch (error: any) {
      console.error('Error fetching core focus:', error.message);
      setNotification({
        open: true,
        message: 'Failed to load core focus. Please try again.',
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };
  
  const handleSaveCoreFocus = async () => {
    if (!coreFocus.purpose.trim() && !coreFocus.niche.trim()) {
      setNotification({
        open: true,
        message: 'Please fill in at least one field before saving.',
        severity: 'warning'
      });
      return;
    }
    
    setSaving(true);
    try {
      let result;
      
      if (coreFocus.id) {
        // Update existing core focus
        result = await visionDb.updateCoreFocus(coreFocus.id, {
          purpose: coreFocus.purpose,
          niche: coreFocus.niche
        });
      } else {
        // Create new core focus
        result = await visionDb.createCoreFocus({
          company_id: companyId,
          purpose: coreFocus.purpose,
          niche: coreFocus.niche
        });
      }
      
      if (result.error) {
        throw result.error;
      }
      
      // Update state with the returned data
      if (result.data && result.data[0]) {
        setCoreFocus(result.data[0]);
      }
      
      setNotification({
        open: true,
        message: 'Core focus saved successfully!',
        severity: 'success'
      });
    } catch (error: any) {
      console.error('Error saving core focus:', error.message);
      setNotification({
        open: true,
        message: 'Failed to save core focus. Please try again.',
        severity: 'error'
      });
    } finally {
      setSaving(false);
    }
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCoreFocus({ ...coreFocus, [name]: value });
  };
  
  const handleCloseNotification = () => {
    setNotification({ ...notification, open: false });
  };
  
  return (
    <Container maxWidth="lg">
      <Box my={4}>
        <Typography variant="h4" component="h1" gutterBottom>
          Core Focus Exercise
          <IconButton 
            color="primary" 
            onClick={() => setShowCoaching(!showCoaching)}
            aria-label="Get AI coaching"
          >
            <HelpOutlineIcon />
          </IconButton>
        </Typography>
        
        <Typography variant="body1" paragraph>
          Your Core Focus consists of your Purpose/Cause/Passion (why your organization exists) and your Niche (what you do better than anyone else).
        </Typography>
        
        {showCoaching && (
          <AICoachingPanel 
            component="Vision" 
            exercise="Core Focus" 
            onClose={() => setShowCoaching(false)}
          />
        )}
        
        <Divider sx={{ my: 3 }} />
        
        {loading ? (
          <Box display="flex" justifyContent="center" my={4}>
            <Typography>Loading core focus...</Typography>
          </Box>
        ) : (
          <>
            <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    Purpose / Cause / Passion
                  </Typography>
                  <Typography variant="body2" color="text.secondary" paragraph>
                    Why does your organization exist? What is your company's purpose or cause? What are you passionate about?
                  </Typography>
                  <TextField
                    fullWidth
                    name="purpose"
                    value={coreFocus.purpose || ''}
                    onChange={handleChange}
                    variant="outlined"
                    multiline
                    rows={3}
                    placeholder="e.g., To inspire and nurture the human spirit"
                  />
                </Grid>
                
                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    Niche
                  </Typography>
                  <Typography variant="body2" color="text.secondary" paragraph>
                    What do you do better than anyone else? What is your area of specialization?
                  </Typography>
                  <TextField
                    fullWidth
                    name="niche"
                    value={coreFocus.niche || ''}
                    onChange={handleChange}
                    variant="outlined"
                    multiline
                    rows={3}
                    placeholder="e.g., Premium coffee experience"
                  />
                </Grid>
                
                <Grid item xs={12} display="flex" justifyContent="flex-end">
                  <Button
                    startIcon={<SaveIcon />}
                    onClick={handleSaveCoreFocus}
                    variant="contained"
                    color="primary"
                    disabled={saving}
                  >
                    {saving ? 'Saving...' : 'Save Core Focus'}
                  </Button>
                </Grid>
              </Grid>
            </Paper>
            
            <Box mt={4} display="flex" justifyContent="space-between">
              <Button
                variant="outlined"
                onClick={() => navigate(`/companies/${companyId}/vision/core-values`)}
              >
                Back: Core Values
              </Button>
              
              <Button
                variant="contained"
                color="primary"
                onClick={() => navigate(`/companies/${companyId}/vision/ten-year-target`)}
              >
                Next: 10-Year Target
              </Button>
            </Box>
          </>
        )}
      </Box>
      
      <Snackbar 
        open={notification.open} 
        autoHideDuration={6000} 
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert onClose={handleCloseNotification} severity={notification.severity as any}>
          {notification.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default CoreFocus;
