import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { visionDb } from '../../lib/supabase';
import { 
  Button, 
  Container, 
  Typography, 
  Box, 
  Grid, 
  TextField, 
  IconButton, 
  Paper,
  Divider,
  Alert,
  Snackbar,
  InputAdornment
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import SaveIcon from '@mui/icons-material/Save';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import AICoachingPanel from '../../components/AICoachingPanel';
import { addYears } from 'date-fns';

const OneYearPlan = () => {
  const { companyId } = useParams<{ companyId: string }>();
  const navigate = useNavigate();
  
  const [oneYearPlan, setOneYearPlan] = useState<any>({
    future_date: addYears(new Date(), 1),
    revenue_goal: '',
    profit_goal: '',
    goals: []
  });
  const [goals, setGoals] = useState<string[]>(['', '', '']);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showCoaching, setShowCoaching] = useState(false);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'success' });
  
  useEffect(() => {
    if (companyId) {
      fetchOneYearPlan();
    }
  }, [companyId]);
  
  const fetchOneYearPlan = async () => {
    setLoading(true);
    try {
      const { data, error } = await visionDb.getOneYearPlan(companyId as string);
      
      if (error) {
        if (error.code === 'PGRST116') {
          // No data found, this is fine for a new company
          setOneYearPlan({
            future_date: addYears(new Date(), 1),
            revenue_goal: '',
            profit_goal: '',
            goals: []
          });
          setGoals(['', '', '']);
        } else {
          throw error;
        }
      } else if (data) {
        // Convert future_date string to Date object
        const updatedData = {
          ...data,
          future_date: data.future_date ? new Date(data.future_date) : addYears(new Date(), 1)
        };
        
        setOneYearPlan(updatedData);
        
        // Set goals from the data
        if (data.goals && Array.isArray(data.goals)) {
          const goalsArray = [...data.goals];
          // Ensure we have at least 3 goal inputs
          while (goalsArray.length < 3) {
            goalsArray.push('');
          }
          setGoals(goalsArray);
        } else {
          setGoals(['', '', '']);
        }
      }
    } catch (error: any) {
      console.error('Error fetching 1-year plan:', error.message);
      setNotification({
        open: true,
        message: 'Failed to load 1-year plan. Please try again.',
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };
  
  const handleSaveOneYearPlan = async () => {
    if (!oneYearPlan.future_date) {
      setNotification({
        open: true,
        message: 'Please set a future date before saving.',
        severity: 'warning'
      });
      return;
    }
    
    // Filter out empty goals
    const filteredGoals = goals.filter(goal => goal.trim() !== '');
    
    setSaving(true);
    try {
      let result;
      
      if (oneYearPlan.id) {
        // Update existing 1-year plan
        result = await visionDb.updateOneYearPlan(oneYearPlan.id, {
          future_date: oneYearPlan.future_date,
          revenue_goal: oneYearPlan.revenue_goal,
          profit_goal: oneYearPlan.profit_goal,
          goals: filteredGoals
        });
      } else {
        // Create new 1-year plan
        result = await visionDb.createOneYearPlan({
          company_id: companyId,
          future_date: oneYearPlan.future_date,
          revenue_goal: oneYearPlan.revenue_goal,
          profit_goal: oneYearPlan.profit_goal,
          goals: filteredGoals
        });
      }
      
      if (result.error) {
        throw result.error;
      }
      
      // Update state with the returned data
      if (result.data && result.data[0]) {
        setOneYearPlan({
          ...result.data[0],
          future_date: result.data[0].future_date ? new Date(result.data[0].future_date) : addYears(new Date(), 1)
        });
        
        // Update goals state
        if (result.data[0].goals && Array.isArray(result.data[0].goals)) {
          const updatedGoals = [...result.data[0].goals];
          while (updatedGoals.length < 3) {
            updatedGoals.push('');
          }
          setGoals(updatedGoals);
        }
      }
      
      setNotification({
        open: true,
        message: '1-year plan saved successfully!',
        severity: 'success'
      });
    } catch (error: any) {
      console.error('Error saving 1-year plan:', error.message);
      setNotification({
        open: true,
        message: 'Failed to save 1-year plan. Please try again.',
        severity: 'error'
      });
    } finally {
      setSaving(false);
    }
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setOneYearPlan({ ...oneYearPlan, [name]: value });
  };
  
  const handleDateChange = (newDate: Date | null) => {
    setOneYearPlan({ ...oneYearPlan, future_date: newDate || addYears(new Date(), 1) });
  };
  
  const handleGoalChange = (index: number, value: string) => {
    const updatedGoals = [...goals];
    updatedGoals[index] = value;
    setGoals(updatedGoals);
  };
  
  const handleAddGoal = () => {
    setGoals([...goals, '']);
  };
  
  const handleRemoveGoal = (index: number) => {
    const updatedGoals = goals.filter((_, i) => i !== index);
    setGoals(updatedGoals);
  };
  
  const handleCloseNotification = () => {
    setNotification({ ...notification, open: false });
  };
  
  return (
    <Container maxWidth="lg">
      <Box my={4}>
        <Typography variant="h4" component="h1" gutterBottom>
          1-Year Plan Exercise
          <IconButton 
            color="primary" 
            onClick={() => setShowCoaching(!showCoaching)}
            aria-label="Get AI coaching"
          >
            <HelpOutlineIcon />
          </IconButton>
        </Typography>
        
        <Typography variant="body1" paragraph>
          Your 1-Year Plan defines what your company must accomplish in the next year to be on track for your 3-Year Picture. It includes specific, measurable goals that will move you toward your longer-term vision.
        </Typography>
        
        {showCoaching && (
          <AICoachingPanel 
            component="Vision" 
            exercise="1-Year Plan" 
            onClose={() => setShowCoaching(false)}
          />
        )}
        
        <Divider sx={{ my: 3 }} />
        
        {loading ? (
          <Box display="flex" justifyContent="center" my={4}>
            <Typography>Loading 1-year plan...</Typography>
          </Box>
        ) : (
          <>
            <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Typography variant="h6" gutterBottom>
                    Future Date
                  </Typography>
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DatePicker
                      label="Future Date (1 year from now)"
                      value={oneYearPlan.future_date}
                      onChange={handleDateChange}
                      slotProps={{
                        textField: {
                          fullWidth: true,
                          variant: 'outlined'
                        }
                      }}
                    />
                  </LocalizationProvider>
                </Grid>
                
                <Grid item xs={12} md={6}>
                  <Typography variant="h6" gutterBottom>
                    Revenue Goal
                  </Typography>
                  <TextField
                    fullWidth
                    name="revenue_goal"
                    label="Revenue Goal"
                    value={oneYearPlan.revenue_goal || ''}
                    onChange={handleChange}
                    variant="outlined"
                    InputProps={{
                      startAdornment: <InputAdornment position="start">$</InputAdornment>,
                    }}
                    placeholder="e.g., 5,000,000"
                  />
                </Grid>
                
                <Grid item xs={12} md={6}>
                  <Typography variant="h6" gutterBottom>
                    Profit Goal
                  </Typography>
                  <TextField
                    fullWidth
                    name="profit_goal"
                    label="Profit Goal"
                    value={oneYearPlan.profit_goal || ''}
                    onChange={handleChange}
                    variant="outlined"
                    InputProps={{
                      startAdornment: <InputAdornment position="start">$</InputAdornment>,
                    }}
                    placeholder="e.g., 750,000"
                  />
                </Grid>
                
                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    1-Year Goals
                  </Typography>
                  <Typography variant="body2" color="text.secondary" paragraph>
                    What are the 3-7 most important goals you must accomplish this year?
                  </Typography>
                  
                  {goals.map((goal, index) => (
                    <Box key={index} display="flex" alignItems="center" mb={2}>
                      <Typography variant="body2" sx={{ mr: 2, minWidth: '80px' }}>
                        Goal {index + 1}:
                      </Typography>
                      <TextField
                        fullWidth
                        value={goal}
                        onChange={(e) => handleGoalChange(index, e.target.value)}
                        variant="outlined"
                        placeholder={`e.g., ${index === 0 ? 'Launch new product line' : index === 1 ? 'Hire 3 new sales representatives' : 'Implement new CRM system'}`}
                        sx={{ mr: 1 }}
                      />
                      <IconButton 
                        onClick={() => handleRemoveGoal(index)}
                        color="error"
                        size="small"
                        disabled={goals.length <= 1}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Box>
                  ))}
                  
                  <Button
                    startIcon={<AddIcon />}
                    onClick={handleAddGoal}
                    variant="outlined"
                    size="small"
                    sx={{ mt: 1 }}
                  >
                    Add Goal
                  </Button>
                </Grid>
                
                <Grid item xs={12} display="flex" justifyContent="flex-end">
                  <Button
                    startIcon={<SaveIcon />}
                    onClick={handleSaveOneYearPlan}
                    variant="contained"
                    color="primary"
                    disabled={saving}
                  >
                    {saving ? 'Saving...' : 'Save 1-Year Plan'}
                  </Button>
                </Grid>
              </Grid>
            </Paper>
            
            <Box mt={4} display="flex" justifyContent="space-between">
              <Button
                variant="outlined"
                onClick={() => navigate(`/companies/${companyId}/vision/three-year-picture`)}
              >
                Back: 3-Year Picture
              </Button>
              
              <Button
                variant="contained"
                color="primary"
                onClick={() => navigate(`/companies/${companyId}/vision/quarterly-rocks`)}
              >
                Next: Quarterly Rocks
              </Button>
            </Box>
          </>
        )}
      </Box>
      
      <Snackbar 
        open={notification.open} 
        autoHideDuration={6000} 
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert onClose={handleCloseNotification} severity={notification.severity as any}>
          {notification.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default OneYearPlan;
