import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Paper, 
  Grid, 
  Button, 
  Card, 
  CardContent, 
  CardActions,
  Divider,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  CircularProgress,
  Alert
} from '@mui/material';
import { useParams, useNavigate } from 'react-router-dom';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import RadioButtonUncheckedIcon from '@mui/icons-material/RadioButtonUnchecked';
import BarChartIcon from '@mui/icons-material/BarChart';
import TimelineIcon from '@mui/icons-material/Timeline';
import GroupIcon from '@mui/icons-material/Group';
import AssignmentIcon from '@mui/icons-material/Assignment';
import SettingsIcon from '@mui/icons-material/Settings';
import SpeedIcon from '@mui/icons-material/Speed';
import AICoachingPanel from '../../components/AICoachingPanel';
import VisionOutputGenerator from '../../components/VisionOutputGenerator';
import { supabase } from '../../lib/supabase';

const VisionDashboard = () => {
  const { companyId } = useParams<{ companyId: string }>();
  const navigate = useNavigate();
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [company, setCompany] = useState<any>(null);
  const [visionData, setVisionData] = useState<any>({});
  const [completionStatus, setCompletionStatus] = useState<Record<string, boolean>>({
    coreValues: false,
    coreFocus: false,
    tenYearTarget: false,
    marketingStrategy: false,
    threeYearPicture: false,
    oneYearPlan: false,
    quarterlyRocks: false
  });
  const [showCoaching, setShowCoaching] = useState(false);
  
  useEffect(() => {
    if (companyId) {
      fetchCompanyData();
      fetchVisionData();
    }
  }, [companyId]);
  
  const fetchCompanyData = async () => {
    try {
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .eq('id', companyId)
        .single();
      
      if (error) throw error;
      
      setCompany(data);
    } catch (error: any) {
      console.error('Error fetching company data:', error.message);
      setError('Failed to load company data. Please try again.');
    }
  };
  
  const fetchVisionData = async () => {
    setLoading(true);
    try {
      // Fetch all vision component data in parallel
      const [
        coreValuesResponse,
        coreFocusResponse,
        tenYearTargetResponse,
        marketingStrategyResponse,
        threeYearPictureResponse,
        oneYearPlanResponse,
        quarterlyPlanResponse
      ] = await Promise.all([
        supabase.from('core_values').select('*').eq('company_id', companyId),
        supabase.from('core_focus').select('*').eq('company_id', companyId).single(),
        supabase.from('ten_year_target').select('*').eq('company_id', companyId).single(),
        supabase.from('marketing_strategy').select('*').eq('company_id', companyId).single(),
        supabase.from('three_year_picture').select('*').eq('company_id', companyId).single(),
        supabase.from('one_year_plan').select('*').eq('company_id', companyId).single(),
        supabase.from('quarterly_plan').select('*').eq('company_id', companyId).single()
      ]);
      
      // Update completion status
      const status = {
        coreValues: !coreValuesResponse.error && coreValuesResponse.data && coreValuesResponse.data.length > 0,
        coreFocus: !coreFocusResponse.error && coreFocusResponse.data !== null,
        tenYearTarget: !tenYearTargetResponse.error && tenYearTargetResponse.data !== null,
        marketingStrategy: !marketingStrategyResponse.error && marketingStrategyResponse.data !== null,
        threeYearPicture: !threeYearPictureResponse.error && threeYearPictureResponse.data !== null,
        oneYearPlan: !oneYearPlanResponse.error && oneYearPlanResponse.data !== null,
        quarterlyRocks: !quarterlyPlanResponse.error && quarterlyPlanResponse.data !== null
      };
      
      setCompletionStatus(status);
      
      // Collect all data
      const data: any = {};
      
      if (coreValuesResponse.data) {
        data.coreValues = coreValuesResponse.data;
      }
      
      if (coreFocusResponse.data) {
        data.coreFocus = coreFocusResponse.data;
      }
      
      if (tenYearTargetResponse.data) {
        data.tenYearTarget = tenYearTargetResponse.data;
      }
      
      if (marketingStrategyResponse.data) {
        data.marketingStrategy = marketingStrategyResponse.data;
      }
      
      if (threeYearPictureResponse.data) {
        data.threeYearPicture = threeYearPictureResponse.data;
      }
      
      if (oneYearPlanResponse.data) {
        data.oneYearPlan = oneYearPlanResponse.data;
      }
      
      if (quarterlyPlanResponse.data) {
        data.quarterlyPlan = quarterlyPlanResponse.data;
        
        // If we have a quarterly plan, fetch rocks
        if (quarterlyPlanResponse.data.id) {
          const [companyRocksResponse, individualRocksResponse] = await Promise.all([
            supabase.from('company_rocks').select('*').eq('quarterly_plan_id', quarterlyPlanResponse.data.id),
            supabase.from('individual_rocks').select('*').eq('quarterly_plan_id', quarterlyPlanResponse.data.id)
          ]);
          
          if (companyRocksResponse.data) {
            data.companyRocks = companyRocksResponse.data;
          }
          
          if (individualRocksResponse.data) {
            data.individualRocks = individualRocksResponse.data;
          }
        }
      }
      
      setVisionData(data);
    } catch (error: any) {
      console.error('Error fetching vision data:', error.message);
      setError('Failed to load vision data. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  const getCompletionPercentage = () => {
    const completedCount = Object.values(completionStatus).filter(Boolean).length;
    const totalCount = Object.keys(completionStatus).length;
    return Math.round((completedCount / totalCount) * 100);
  };
  
  const renderExerciseCard = (title: string, description: string, path: string, completed: boolean, icon: React.ReactNode) => (
    <Card elevation={3} sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <CardContent sx={{ flexGrow: 1 }}>
        <Box display="flex" alignItems="center" mb={1}>
          {icon}
          <Typography variant="h6" component="h3" ml={1}>
            {title}
          </Typography>
        </Box>
        <Box display="flex" alignItems="center" mb={2}>
          {completed ? (
            <CheckCircleIcon color="success" fontSize="small" sx={{ mr: 1 }} />
          ) : (
            <RadioButtonUncheckedIcon color="action" fontSize="small" sx={{ mr: 1 }} />
          )}
          <Typography variant="body2" color={completed ? 'success.main' : 'text.secondary'}>
            {completed ? 'Completed' : 'Not started'}
          </Typography>
        </Box>
        <Typography variant="body2" color="text.secondary">
          {description}
        </Typography>
      </CardContent>
      <CardActions>
        <Button 
          size="small" 
          color="primary" 
          onClick={() => navigate(`/companies/${companyId}/vision/${path}`)}
        >
          {completed ? 'Edit' : 'Start'}
        </Button>
      </CardActions>
    </Card>
  );
  
  if (loading) {
    return (
      <Container maxWidth="lg">
        <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
          <CircularProgress />
        </Box>
      </Container>
    );
  }
  
  return (
    <Container maxWidth="lg">
      <Box my={4}>
        <Typography variant="h4" component="h1" gutterBottom>
          Vision Dashboard
        </Typography>
        
        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}
        
        <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Typography variant="h5" gutterBottom>
                {company?.name || 'Your Company'}
              </Typography>
              <Typography variant="body1">
                Vision Component Progress
              </Typography>
            </Grid>
            <Grid item xs={12} md={6}>
              <Box display="flex" alignItems="center" justifyContent="flex-end">
                <Box position="relative" display="inline-flex">
                  <CircularProgress 
                    variant="determinate" 
                    value={getCompletionPercentage()} 
                    size={80} 
                    thickness={5}
                    color="primary"
                  />
                  <Box
                    top={0}
                    left={0}
                    bottom={0}
                    right={0}
                    position="absolute"
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                  >
                    <Typography variant="h6" component="div" color="text.primary">
                      {`${getCompletionPercentage()}%`}
                    </Typography>
                  </Box>
                </Box>
              </Box>
            </Grid>
          </Grid>
          
          <Divider sx={{ my: 3 }} />
          
          <Typography variant="h6" gutterBottom>
            Vision Component Exercises
          </Typography>
          
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} sm={6} md={4}>
              {renderExerciseCard(
                'Core Values',
                'Define the guiding principles that dictate behavior and action for your company.',
                'core-values',
                completionStatus.coreValues,
                <GroupIcon color="primary" />
              )}
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              {renderExerciseCard(
                'Core Focus',
                'Identify your company\'s purpose/cause/passion and niche.',
                'core-focus',
                completionStatus.coreFocus,
                <SettingsIcon color="primary" />
              )}
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              {renderExerciseCard(
                '10-Year Target',
                'Set a long-term goal that provides direction for your company.',
                'ten-year-target',
                completionStatus.tenYearTarget,
                <TimelineIcon color="primary" />
              )}
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              {renderExerciseCard(
                'Marketing Strategy',
                'Define your target market, three uniques, proven process, and guarantee.',
                'marketing-strategy',
                completionStatus.marketingStrategy,
                <BarChartIcon color="primary" />
              )}
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              {renderExerciseCard(
                '3-Year Picture',
                'Create a clear vision of what your company will look like in three years.',
                'three-year-picture',
                completionStatus.threeYearPicture,
                <AssignmentIcon color="primary" />
              )}
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              {renderExerciseCard(
                '1-Year Plan',
                'Set specific goals for the next year that move you toward your 3-Year Picture.',
                'one-year-plan',
                completionStatus.oneYearPlan,
                <AssignmentIcon color="primary" />
              )}
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              {renderExerciseCard(
                'Quarterly Rocks',
                'Define the most important priorities for your company and individuals for the next 90 days.',
                'quarterly-rocks',
                completionStatus.quarterlyRocks,
                <SpeedIcon color="primary" />
              )}
            </Grid>
          </Grid>
          
          <Box mb={4}>
            <Button 
              variant="outlined" 
              color="primary" 
              onClick={() => setShowCoaching(!showCoaching)}
            >
              {showCoaching ? 'Hide AI Coaching' : 'Get AI Coaching'}
            </Button>
          </Box>
          
          {showCoaching && (
            <AICoachingPanel 
              component="Vision" 
              exercise="Dashboard" 
              onClose={() => setShowCoaching(false)}
            />
          )}
          
          {getCompletionPercentage() > 0 && (
            <VisionOutputGenerator 
              companyId={companyId as string}
              companyName={company?.name || 'Your Company'}
              visionData={visionData}
            />
          )}
        </Paper>
      </Box>
    </Container>
  );
};

export default VisionDashboard;
