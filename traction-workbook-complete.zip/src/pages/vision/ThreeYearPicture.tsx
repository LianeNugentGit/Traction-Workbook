import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { visionDb } from '../../lib/supabase';
import { 
  Button, 
  Container, 
  Typography, 
  Box, 
  Grid, 
  TextField, 
  IconButton, 
  Paper,
  Divider,
  Alert,
  Snackbar,
  InputAdornment
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import SaveIcon from '@mui/icons-material/Save';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import AICoachingPanel from '../../components/AICoachingPanel';
import { addYears } from 'date-fns';

const ThreeYearPicture = () => {
  const { companyId } = useParams<{ companyId: string }>();
  const navigate = useNavigate();
  
  const [threeYearPicture, setThreeYearPicture] = useState<any>({
    future_date: addYears(new Date(), 3),
    revenue: '',
    profit: '',
    measurables: {},
    future_state: ''
  });
  const [measurableInputs, setMeasurableInputs] = useState<{key: string, value: string}[]>([
    { key: 'Number of Customers', value: '' },
    { key: 'Number of Employees', value: '' }
  ]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showCoaching, setShowCoaching] = useState(false);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'success' });
  
  useEffect(() => {
    if (companyId) {
      fetchThreeYearPicture();
    }
  }, [companyId]);
  
  const fetchThreeYearPicture = async () => {
    setLoading(true);
    try {
      const { data, error } = await visionDb.getThreeYearPicture(companyId as string);
      
      if (error) {
        if (error.code === 'PGRST116') {
          // No data found, this is fine for a new company
          setThreeYearPicture({
            future_date: addYears(new Date(), 3),
            revenue: '',
            profit: '',
            measurables: {},
            future_state: ''
          });
        } else {
          throw error;
        }
      } else if (data) {
        // Convert future_date string to Date object
        const updatedData = {
          ...data,
          future_date: data.future_date ? new Date(data.future_date) : addYears(new Date(), 3)
        };
        
        setThreeYearPicture(updatedData);
        
        // Convert measurables object to array of key-value pairs for inputs
        if (data.measurables) {
          const measurableArray = Object.entries(data.measurables).map(([key, value]) => ({
            key,
            value: value as string
          }));
          
          // Ensure we have at least the default measurables
          const defaultKeys = ['Number of Customers', 'Number of Employees'];
          defaultKeys.forEach(key => {
            if (!measurableArray.some(m => m.key === key)) {
              measurableArray.push({ key, value: '' });
            }
          });
          
          setMeasurableInputs(measurableArray);
        }
      }
    } catch (error: any) {
      console.error('Error fetching 3-year picture:', error.message);
      setNotification({
        open: true,
        message: 'Failed to load 3-year picture. Please try again.',
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };
  
  const handleSaveThreeYearPicture = async () => {
    if (!threeYearPicture.future_date) {
      setNotification({
        open: true,
        message: 'Please set a future date before saving.',
        severity: 'warning'
      });
      return;
    }
    
    setSaving(true);
    try {
      // Convert measurable inputs to object
      const measurables = measurableInputs.reduce((acc, { key, value }) => {
        if (key.trim() !== '') {
          acc[key] = value;
        }
        return acc;
      }, {} as Record<string, string>);
      
      let result;
      
      if (threeYearPicture.id) {
        // Update existing 3-year picture
        result = await visionDb.updateThreeYearPicture(threeYearPicture.id, {
          future_date: threeYearPicture.future_date,
          revenue: threeYearPicture.revenue,
          profit: threeYearPicture.profit,
          measurables,
          future_state: threeYearPicture.future_state
        });
      } else {
        // Create new 3-year picture
        result = await visionDb.createThreeYearPicture({
          company_id: companyId,
          future_date: threeYearPicture.future_date,
          revenue: threeYearPicture.revenue,
          profit: threeYearPicture.profit,
          measurables,
          future_state: threeYearPicture.future_state
        });
      }
      
      if (result.error) {
        throw result.error;
      }
      
      // Update state with the returned data
      if (result.data && result.data[0]) {
        setThreeYearPicture({
          ...result.data[0],
          future_date: result.data[0].future_date ? new Date(result.data[0].future_date) : addYears(new Date(), 3)
        });
      }
      
      setNotification({
        open: true,
        message: '3-year picture saved successfully!',
        severity: 'success'
      });
    } catch (error: any) {
      console.error('Error saving 3-year picture:', error.message);
      setNotification({
        open: true,
        message: 'Failed to save 3-year picture. Please try again.',
        severity: 'error'
      });
    } finally {
      setSaving(false);
    }
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setThreeYearPicture({ ...threeYearPicture, [name]: value });
  };
  
  const handleDateChange = (newDate: Date | null) => {
    setThreeYearPicture({ ...threeYearPicture, future_date: newDate || addYears(new Date(), 3) });
  };
  
  const handleMeasurableKeyChange = (index: number, value: string) => {
    const updatedMeasurables = [...measurableInputs];
    updatedMeasurables[index].key = value;
    setMeasurableInputs(updatedMeasurables);
  };
  
  const handleMeasurableValueChange = (index: number, value: string) => {
    const updatedMeasurables = [...measurableInputs];
    updatedMeasurables[index].value = value;
    setMeasurableInputs(updatedMeasurables);
  };
  
  const handleAddMeasurable = () => {
    setMeasurableInputs([...measurableInputs, { key: '', value: '' }]);
  };
  
  const handleRemoveMeasurable = (index: number) => {
    const updatedMeasurables = measurableInputs.filter((_, i) => i !== index);
    setMeasurableInputs(updatedMeasurables);
  };
  
  const handleCloseNotification = () => {
    setNotification({ ...notification, open: false });
  };
  
  return (
    <Container maxWidth="lg">
      <Box my={4}>
        <Typography variant="h4" component="h1" gutterBottom>
          3-Year Picture Exercise
          <IconButton 
            color="primary" 
            onClick={() => setShowCoaching(!showCoaching)}
            aria-label="Get AI coaching"
          >
            <HelpOutlineIcon />
          </IconButton>
        </Typography>
        
        <Typography variant="body1" paragraph>
          Your 3-Year Picture is a clear, detailed vision of what your company will look like three years from now. It includes specific, measurable targets that will help you achieve your 10-Year Target.
        </Typography>
        
        {showCoaching && (
          <AICoachingPanel 
            component="Vision" 
            exercise="3-Year Picture" 
            onClose={() => setShowCoaching(false)}
          />
        )}
        
        <Divider sx={{ my: 3 }} />
        
        {loading ? (
          <Box display="flex" justifyContent="center" my={4}>
            <Typography>Loading 3-year picture...</Typography>
          </Box>
        ) : (
          <>
            <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Typography variant="h6" gutterBottom>
                    Future Date
                  </Typography>
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DatePicker
                      label="Future Date (3 years from now)"
                      value={threeYearPicture.future_date}
                      onChange={handleDateChange}
                      slotProps={{
                        textField: {
                          fullWidth: true,
                          variant: 'outlined'
                        }
                      }}
                    />
                  </LocalizationProvider>
                </Grid>
                
                <Grid item xs={12} md={6}>
                  <Typography variant="h6" gutterBottom>
                    Revenue
                  </Typography>
                  <TextField
                    fullWidth
                    name="revenue"
                    label="Revenue"
                    value={threeYearPicture.revenue || ''}
                    onChange={handleChange}
                    variant="outlined"
                    InputProps={{
                      startAdornment: <InputAdornment position="start">$</InputAdornment>,
                    }}
                    placeholder="e.g., 10,000,000"
                  />
                </Grid>
                
                <Grid item xs={12} md={6}>
                  <Typography variant="h6" gutterBottom>
                    Profit
                  </Typography>
                  <TextField
                    fullWidth
                    name="profit"
                    label="Profit"
                    value={threeYearPicture.profit || ''}
                    onChange={handleChange}
                    variant="outlined"
                    InputProps={{
                      startAdornment: <InputAdornment position="start">$</InputAdornment>,
                    }}
                    placeholder="e.g., 2,000,000"
                  />
                </Grid>
                
                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    Other Measurables
                  </Typography>
                  <Typography variant="body2" color="text.secondary" paragraph>
                    What other metrics will you be tracking in three years?
                  </Typography>
                  
                  {measurableInputs.map((measurable, index) => (
                    <Box key={index} display="flex" alignItems="center" mb={2}>
                      <TextField
                        label="Measurable"
                        value={measurable.key}
                        onChange={(e) => handleMeasurableKeyChange(index, e.target.value)}
                        variant="outlined"
                        placeholder="e.g., Number of Locations"
                        sx={{ mr: 2, flexBasis: '50%' }}
                      />
                      <TextField
                        label="Value"
                        value={measurable.value}
                        onChange={(e) => handleMeasurableValueChange(index, e.target.value)}
                        variant="outlined"
                        placeholder="e.g., 5"
                        sx={{ mr: 1, flexBasis: '40%' }}
                      />
                      <IconButton 
                        onClick={() => handleRemoveMeasurable(index)}
                        color="error"
                        size="small"
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Box>
                  ))}
                  
                  <Button
                    startIcon={<AddIcon />}
                    onClick={handleAddMeasurable}
                    variant="outlined"
                    size="small"
                    sx={{ mt: 1 }}
                  >
                    Add Measurable
                  </Button>
                </Grid>
                
                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    Future State
                  </Typography>
                  <Typography variant="body2" color="text.secondary" paragraph>
                    Describe what your company will look like in three years. What will people see, hear, and feel when they visit?
                  </Typography>
                  <TextField
                    fullWidth
                    name="future_state"
                    value={threeYearPicture.future_state || ''}
                    onChange={handleChange}
                    variant="outlined"
                    multiline
                    rows={4}
                    placeholder="e.g., Recognized industry leader with strong brand presence in North America and Europe. Award-winning workplace culture with high employee retention."
                  />
                </Grid>
                
                <Grid item xs={12} display="flex" justifyContent="flex-end">
                  <Button
                    startIcon={<SaveIcon />}
                    onClick={handleSaveThreeYearPicture}
                    variant="contained"
                    color="primary"
                    disabled={saving}
                  >
                    {saving ? 'Saving...' : 'Save 3-Year Picture'}
                  </Button>
                </Grid>
              </Grid>
            </Paper>
            
            <Box mt={4} display="flex" justifyContent="space-between">
              <Button
                variant="outlined"
                onClick={() => navigate(`/companies/${companyId}/vision/marketing-strategy`)}
              >
                Back: Marketing Strategy
              </Button>
              
              <Button
                variant="contained"
                color="primary"
                onClick={() => navigate(`/companies/${companyId}/vision/one-year-plan`)}
              >
                Next: 1-Year Plan
              </Button>
            </Box>
          </>
        )}
      </Box>
      
      <Snackbar 
        open={notification.open} 
        autoHideDuration={6000} 
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert onClose={handleCloseNotification} severity={notification.severity as any}>
          {notification.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default ThreeYearPicture;
