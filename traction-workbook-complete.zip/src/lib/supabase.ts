import { createClient } from '@supabase/supabase-js';

// Initialize the Supabase client
// In a production environment, these would be environment variables
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Missing Supabase URL or Anonymous Key. Please check your environment variables.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Authentication helper functions
export const auth = {
  // Sign up a new user
  signUp: async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });
    return { data, error };
  },

  // Sign in an existing user
  signIn: async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    return { data, error };
  },

  // Sign out the current user
  signOut: async () => {
    const { error } = await supabase.auth.signOut();
    return { error };
  },

  // Get the current user
  getUser: async () => {
    const { data, error } = await supabase.auth.getUser();
    return { data, error };
  },

  // Get the current session
  getSession: async () => {
    const { data, error } = await supabase.auth.getSession();
    return { data, error };
  },

  // Reset password
  resetPassword: async (email: string) => {
    const { data, error } = await supabase.auth.resetPasswordForEmail(email);
    return { data, error };
  },

  // Update user
  updateUser: async (attributes: { email?: string; password?: string; data?: { [key: string]: any } }) => {
    const { data, error } = await supabase.auth.updateUser(attributes);
    return { data, error };
  },
};

// Database helper functions for Vision component
export const visionDb = {
  // Core Values
  getCoreValues: async (companyId: string) => {
    const { data, error } = await supabase
      .from('core_values')
      .select('*')
      .eq('company_id', companyId)
      .order('order_num', { ascending: true });
    return { data, error };
  },

  createCoreValue: async (coreValue: any) => {
    const { data, error } = await supabase
      .from('core_values')
      .insert(coreValue)
      .select();
    return { data, error };
  },

  updateCoreValue: async (id: string, updates: any) => {
    const { data, error } = await supabase
      .from('core_values')
      .update(updates)
      .eq('id', id)
      .select();
    return { data, error };
  },

  deleteCoreValue: async (id: string) => {
    const { error } = await supabase
      .from('core_values')
      .delete()
      .eq('id', id);
    return { error };
  },

  // Core Focus
  getCoreFocus: async (companyId: string) => {
    const { data, error } = await supabase
      .from('core_focus')
      .select('*')
      .eq('company_id', companyId)
      .single();
    return { data, error };
  },

  createCoreFocus: async (coreFocus: any) => {
    const { data, error } = await supabase
      .from('core_focus')
      .insert(coreFocus)
      .select();
    return { data, error };
  },

  updateCoreFocus: async (id: string, updates: any) => {
    const { data, error } = await supabase
      .from('core_focus')
      .update(updates)
      .eq('id', id)
      .select();
    return { data, error };
  },

  // 10-Year Target
  getTenYearTarget: async (companyId: string) => {
    const { data, error } = await supabase
      .from('ten_year_target')
      .select('*')
      .eq('company_id', companyId)
      .single();
    return { data, error };
  },

  createTenYearTarget: async (tenYearTarget: any) => {
    const { data, error } = await supabase
      .from('ten_year_target')
      .insert(tenYearTarget)
      .select();
    return { data, error };
  },

  updateTenYearTarget: async (id: string, updates: any) => {
    const { data, error } = await supabase
      .from('ten_year_target')
      .update(updates)
      .eq('id', id)
      .select();
    return { data, error };
  },

  // Marketing Strategy
  getMarketingStrategy: async (companyId: string) => {
    const { data, error } = await supabase
      .from('marketing_strategy')
      .select('*')
      .eq('company_id', companyId)
      .single();
    return { data, error };
  },

  createMarketingStrategy: async (marketingStrategy: any) => {
    const { data, error } = await supabase
      .from('marketing_strategy')
      .insert(marketingStrategy)
      .select();
    return { data, error };
  },

  updateMarketingStrategy: async (id: string, updates: any) => {
    const { data, error } = await supabase
      .from('marketing_strategy')
      .update(updates)
      .eq('id', id)
      .select();
    return { data, error };
  },

  // Three Year Picture
  getThreeYearPicture: async (companyId: string) => {
    const { data, error } = await supabase
      .from('three_year_picture')
      .select('*')
      .eq('company_id', companyId)
      .single();
    return { data, error };
  },

  createThreeYearPicture: async (threeYearPicture: any) => {
    const { data, error } = await supabase
      .from('three_year_picture')
      .insert(threeYearPicture)
      .select();
    return { data, error };
  },

  updateThreeYearPicture: async (id: string, updates: any) => {
    const { data, error } = await supabase
      .from('three_year_picture')
      .update(updates)
      .eq('id', id)
      .select();
    return { data, error };
  },

  // One Year Plan
  getOneYearPlan: async (companyId: string) => {
    const { data, error } = await supabase
      .from('one_year_plan')
      .select('*')
      .eq('company_id', companyId)
      .single();
    return { data, error };
  },

  createOneYearPlan: async (oneYearPlan: any) => {
    const { data, error } = await supabase
      .from('one_year_plan')
      .insert(oneYearPlan)
      .select();
    return { data, error };
  },

  updateOneYearPlan: async (id: string, updates: any) => {
    const { data, error } = await supabase
      .from('one_year_plan')
      .update(updates)
      .eq('id', id)
      .select();
    return { data, error };
  },

  // Quarterly Rocks
  getQuarterlyPlan: async (companyId: string) => {
    const { data, error } = await supabase
      .from('quarterly_plan')
      .select('*')
      .eq('company_id', companyId)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();
    return { data, error };
  },

  createQuarterlyPlan: async (quarterlyPlan: any) => {
    const { data, error } = await supabase
      .from('quarterly_plan')
      .insert(quarterlyPlan)
      .select();
    return { data, error };
  },

  updateQuarterlyPlan: async (id: string, updates: any) => {
    const { data, error } = await supabase
      .from('quarterly_plan')
      .update(updates)
      .eq('id', id)
      .select();
    return { data, error };
  },

  // Company Rocks
  getCompanyRocks: async (quarterlyPlanId: string) => {
    const { data, error } = await supabase
      .from('company_rocks')
      .select('*')
      .eq('quarterly_plan_id', quarterlyPlanId)
      .order('order_num', { ascending: true });
    return { data, error };
  },

  createCompanyRock: async (companyRock: any) => {
    const { data, error } = await supabase
      .from('company_rocks')
      .insert(companyRock)
      .select();
    return { data, error };
  },

  updateCompanyRock: async (id: string, updates: any) => {
    const { data, error } = await supabase
      .from('company_rocks')
      .update(updates)
      .eq('id', id)
      .select();
    return { data, error };
  },

  deleteCompanyRock: async (id: string) => {
    const { error } = await supabase
      .from('company_rocks')
      .delete()
      .eq('id', id);
    return { error };
  },

  // Individual Rocks
  getIndividualRocks: async (quarterlyPlanId: string) => {
    const { data, error } = await supabase
      .from('individual_rocks')
      .select('*')
      .eq('quarterly_plan_id', quarterlyPlanId);
    return { data, error };
  },

  createIndividualRock: async (individualRock: any) => {
    const { data, error } = await supabase
      .from('individual_rocks')
      .insert(individualRock)
      .select();
    return { data, error };
  },

  updateIndividualRock: async (id: string, updates: any) => {
    const { data, error } = await supabase
      .from('individual_rocks')
      .update(updates)
      .eq('id', id)
      .select();
    return { data, error };
  },

  deleteIndividualRock: async (id: string) => {
    const { error } = await supabase
      .from('individual_rocks')
      .delete()
      .eq('id', id);
    return { error };
  },

  // Companies
  getCompanies: async (userId: string) => {
    const { data, error } = await supabase
      .from('companies')
      .select('*')
      .eq('user_id', userId);
    return { data, error };
  },

  getCompany: async (id: string) => {
    const { data, error } = await supabase
      .from('companies')
      .select('*')
      .eq('id', id)
      .single();
    return { data, error };
  },

  createCompany: async (company: any) => {
    const { data, error } = await supabase
      .from('companies')
      .insert(company)
      .select();
    return { data, error };
  },

  updateCompany: async (id: string, updates: any) => {
    const { data, error } = await supabase
      .from('companies')
      .update(updates)
      .eq('id', id)
      .select();
    return { data, error };
  },

  deleteCompany: async (id: string) => {
    const { error } = await supabase
      .from('companies')
      .delete()
      .eq('id', id);
    return { error };
  },
};
