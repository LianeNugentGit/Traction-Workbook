import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './lib/auth-context';

// Auth Pages
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import ForgotPassword from './pages/auth/ForgotPassword';

// Main Pages
import Dashboard from './pages/Dashboard';
import CompanyList from './pages/CompanyList';
import CompanyCreate from './pages/CompanyCreate';

// Vision Component Pages
import VisionDashboard from './pages/vision/VisionDashboard';
import CoreValues from './pages/vision/CoreValues';
import CoreFocus from './pages/vision/CoreFocus';
import TenYearTarget from './pages/vision/TenYearTarget';
import MarketingStrategy from './pages/vision/MarketingStrategy';
import ThreeYearPicture from './pages/vision/ThreeYearPicture';
import OneYearPlan from './pages/vision/OneYearPlan';
import QuarterlyRocks from './pages/vision/QuarterlyRocks';

// Layout Components
import Layout from './components/Layout';

// Protected Route Component
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, loading } = useAuth();
  
  if (loading) {
    return <div>Loading...</div>;
  }
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Auth Routes */}
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          
          {/* Protected Routes */}
          <Route path="/" element={
            <ProtectedRoute>
              <Layout>
                <Dashboard />
              </Layout>
            </ProtectedRoute>
          } />
          
          <Route path="/companies" element={
            <ProtectedRoute>
              <Layout>
                <CompanyList />
              </Layout>
            </ProtectedRoute>
          } />
          
          <Route path="/companies/create" element={
            <ProtectedRoute>
              <Layout>
                <CompanyCreate />
              </Layout>
            </ProtectedRoute>
          } />
          
          {/* Vision Component Routes */}
          <Route path="/companies/:companyId/vision" element={
            <ProtectedRoute>
              <Layout>
                <VisionDashboard />
              </Layout>
            </ProtectedRoute>
          } />
          
          <Route path="/companies/:companyId/vision/core-values" element={
            <ProtectedRoute>
              <Layout>
                <CoreValues />
              </Layout>
            </ProtectedRoute>
          } />
          
          <Route path="/companies/:companyId/vision/core-focus" element={
            <ProtectedRoute>
              <Layout>
                <CoreFocus />
              </Layout>
            </ProtectedRoute>
          } />
          
          <Route path="/companies/:companyId/vision/ten-year-target" element={
            <ProtectedRoute>
              <Layout>
                <TenYearTarget />
              </Layout>
            </ProtectedRoute>
          } />
          
          <Route path="/companies/:companyId/vision/marketing-strategy" element={
            <ProtectedRoute>
              <Layout>
                <MarketingStrategy />
              </Layout>
            </ProtectedRoute>
          } />
          
          <Route path="/companies/:companyId/vision/three-year-picture" element={
            <ProtectedRoute>
              <Layout>
                <ThreeYearPicture />
              </Layout>
            </ProtectedRoute>
          } />
          
          <Route path="/companies/:companyId/vision/one-year-plan" element={
            <ProtectedRoute>
              <Layout>
                <OneYearPlan />
              </Layout>
            </ProtectedRoute>
          } />
          
          <Route path="/companies/:companyId/vision/quarterly-rocks" element={
            <ProtectedRoute>
              <Layout>
                <QuarterlyRocks />
              </Layout>
            </ProtectedRoute>
          } />
          
          {/* Catch all route */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
