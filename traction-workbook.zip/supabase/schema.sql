CREATE TABLE public.users (
  id UUID REFERENCES auth.users NOT NULL PRIMARY KEY,
  email TEXT NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Set up Row Level Security (RLS)
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own data" ON public.users
  FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update their own data" ON public.users
  FOR UPDATE USING (auth.uid() = id);

-- Companies table
CREATE TABLE public.companies (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES public.users NOT NULL,
  name TEXT NOT NULL,
  industry TEXT,
  size TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Set up RLS for companies
ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own companies" ON public.companies
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own companies" ON public.companies
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own companies" ON public.companies
  FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own companies" ON public.companies
  FOR DELETE USING (auth.uid() = user_id);

-- Core Values table
CREATE TABLE public.core_values (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  company_id UUID REFERENCES public.companies NOT NULL,
  value_name TEXT NOT NULL,
  description TEXT,
  behaviors TEXT[],
  order_num INTEGER NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Set up RLS for core_values
ALTER TABLE public.core_values ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own core values" ON public.core_values
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = core_values.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can insert their own core values" ON public.core_values
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = core_values.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can update their own core values" ON public.core_values
  FOR UPDATE USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = core_values.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can delete their own core values" ON public.core_values
  FOR DELETE USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = core_values.company_id
    AND companies.user_id = auth.uid()
  ));

-- Core Focus table
CREATE TABLE public.core_focus (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  company_id UUID REFERENCES public.companies NOT NULL,
  purpose TEXT,
  niche TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  UNIQUE(company_id)
);

-- Set up RLS for core_focus
ALTER TABLE public.core_focus ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own core focus" ON public.core_focus
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = core_focus.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can insert their own core focus" ON public.core_focus
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = core_focus.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can update their own core focus" ON public.core_focus
  FOR UPDATE USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = core_focus.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can delete their own core focus" ON public.core_focus
  FOR DELETE USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = core_focus.company_id
    AND companies.user_id = auth.uid()
  ));

-- Ten Year Target table
CREATE TABLE public.ten_year_target (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  company_id UUID REFERENCES public.companies NOT NULL,
  target_description TEXT NOT NULL,
  target_date DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  UNIQUE(company_id)
);

-- Set up RLS for ten_year_target
ALTER TABLE public.ten_year_target ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own ten year target" ON public.ten_year_target
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = ten_year_target.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can insert their own ten year target" ON public.ten_year_target
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = ten_year_target.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can update their own ten year target" ON public.ten_year_target
  FOR UPDATE USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = ten_year_target.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can delete their own ten year target" ON public.ten_year_target
  FOR DELETE USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = ten_year_target.company_id
    AND companies.user_id = auth.uid()
  ));

-- Marketing Strategy table
CREATE TABLE public.marketing_strategy (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  company_id UUID REFERENCES public.companies NOT NULL,
  target_market TEXT,
  uniques TEXT[],
  proven_process TEXT,
  guarantee TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  UNIQUE(company_id)
);

-- Set up RLS for marketing_strategy
ALTER TABLE public.marketing_strategy ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own marketing strategy" ON public.marketing_strategy
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = marketing_strategy.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can insert their own marketing strategy" ON public.marketing_strategy
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = marketing_strategy.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can update their own marketing strategy" ON public.marketing_strategy
  FOR UPDATE USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = marketing_strategy.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can delete their own marketing strategy" ON public.marketing_strategy
  FOR DELETE USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = marketing_strategy.company_id
    AND companies.user_id = auth.uid()
  ));

-- Three Year Picture table
CREATE TABLE public.three_year_picture (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  company_id UUID REFERENCES public.companies NOT NULL,
  future_date DATE NOT NULL,
  revenue NUMERIC,
  profit NUMERIC,
  measurables JSONB,
  future_state TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  UNIQUE(company_id)
);

-- Set up RLS for three_year_picture
ALTER TABLE public.three_year_picture ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own three year picture" ON public.three_year_picture
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = three_year_picture.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can insert their own three year picture" ON public.three_year_picture
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = three_year_picture.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can update their own three year picture" ON public.three_year_picture
  FOR UPDATE USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = three_year_picture.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can delete their own three year picture" ON public.three_year_picture
  FOR DELETE USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = three_year_picture.company_id
    AND companies.user_id = auth.uid()
  ));

-- One Year Plan table
CREATE TABLE public.one_year_plan (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  company_id UUID REFERENCES public.companies NOT NULL,
  future_date DATE NOT NULL,
  revenue_goal NUMERIC,
  profit_goal NUMERIC,
  goals JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  UNIQUE(company_id)
);

-- Set up RLS for one_year_plan
ALTER TABLE public.one_year_plan ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own one year plan" ON public.one_year_plan
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = one_year_plan.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can insert their own one year plan" ON public.one_year_plan
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = one_year_plan.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can update their own one year plan" ON public.one_year_plan
  FOR UPDATE USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = one_year_plan.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can delete their own one year plan" ON public.one_year_plan
  FOR DELETE USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = one_year_plan.company_id
    AND companies.user_id = auth.uid()
  ));

-- Quarterly Plan table
CREATE TABLE public.quarterly_plan (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  company_id UUID REFERENCES public.companies NOT NULL,
  quarter_name TEXT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Set up RLS for quarterly_plan
ALTER TABLE public.quarterly_plan ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own quarterly plan" ON public.quarterly_plan
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = quarterly_plan.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can insert their own quarterly plan" ON public.quarterly_plan
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = quarterly_plan.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can update their own quarterly plan" ON public.quarterly_plan
  FOR UPDATE USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = quarterly_plan.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can delete their own quarterly plan" ON public.quarterly_plan
  FOR DELETE USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = quarterly_plan.company_id
    AND companies.user_id = auth.uid()
  ));

-- Company Rocks table
CREATE TABLE public.company_rocks (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  quarterly_plan_id UUID REFERENCES public.quarterly_plan NOT NULL,
  rock_description TEXT NOT NULL,
  measurable TEXT,
  owner_id UUID,
  order_num INTEGER NOT NULL,
  status TEXT DEFAULT 'on-track',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Set up RLS for company_rocks
ALTER TABLE public.company_rocks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own company rocks" ON public.company_rocks
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM public.quarterly_plan
    JOIN public.companies ON companies.id = quarterly_plan.company_id
    WHERE quarterly_plan.id = company_rocks.quarterly_plan_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can insert their own company rocks" ON public.company_rocks
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM public.quarterly_plan
    JOIN public.companies ON companies.id = quarterly_plan.company_id
    WHERE quarterly_plan.id = company_rocks.quarterly_plan_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can update their own company rocks" ON public.company_rocks
  FOR UPDATE USING (EXISTS (
    SELECT 1 FROM public.quarterly_plan
    JOIN public.companies ON companies.id = quarterly_plan.company_id
    WHERE quarterly_plan.id = company_rocks.quarterly_plan_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can delete their own company rocks" ON public.company_rocks
  FOR DELETE USING (EXISTS (
    SELECT 1 FROM public.quarterly_plan
    JOIN public.companies ON companies.id = quarterly_plan.company_id
    WHERE quarterly_plan.id = company_rocks.quarterly_plan_id
    AND companies.user_id = auth.uid()
  ));

-- Individual Rocks table
CREATE TABLE public.individual_rocks (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  quarterly_plan_id UUID REFERENCES public.quarterly_plan NOT NULL,
  rock_description TEXT NOT NULL,
  measurable TEXT,
  owner_id UUID NOT NULL,
  status TEXT DEFAULT 'on-track',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Set up RLS for individual_rocks
ALTER TABLE public.individual_rocks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own individual rocks" ON public.individual_rocks
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM public.quarterly_plan
    JOIN public.companies ON companies.id = quarterly_plan.company_id
    WHERE quarterly_plan.id = individual_rocks.quarterly_plan_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can insert their own individual rocks" ON public.individual_rocks
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM public.quarterly_plan
    JOIN public.companies ON companies.id = quarterly_plan.company_id
    WHERE quarterly_plan.id = individual_rocks.quarterly_plan_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can update their own individual rocks" ON public.individual_rocks
  FOR UPDATE USING (EXISTS (
    SELECT 1 FROM public.quarterly_plan
    JOIN public.companies ON companies.id = quarterly_plan.company_id
    WHERE quarterly_plan.id = individual_rocks.quarterly_plan_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can delete their own individual rocks" ON public.individual_rocks
  FOR DELETE USING (EXISTS (
    SELECT 1 FROM public.quarterly_plan
    JOIN public.companies ON companies.id = quarterly_plan.company_id
    WHERE quarterly_plan.id = individual_rocks.quarterly_plan_id
    AND companies.user_id = auth.uid()
  ));

-- Team Members table
CREATE TABLE public.team_members (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  company_id UUID REFERENCES public.companies NOT NULL,
  name TEXT NOT NULL,
  role TEXT,
  email TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Set up RLS for team_members
ALTER TABLE public.team_members ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own team members" ON public.team_members
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = team_members.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can insert their own team members" ON public.team_members
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = team_members.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can update their own team members" ON public.team_members
  FOR UPDATE USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = team_members.company_id
    AND companies.user_id = auth.uid()
  ));
CREATE POLICY "Users can delete their own team members" ON public.team_members
  FOR DELETE USING (EXISTS (
    SELECT 1 FROM public.companies
    WHERE companies.id = team_members.company_id
    AND companies.user_id = auth.uid()
  ));

-- Create trigger function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
   NEW.updated_at = NOW();
   RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply trigger to all tables
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_companies_updated_at BEFORE UPDATE ON public.companies
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_core_values_updated_at BEFORE UPDATE ON public.core_values
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_core_focus_updated_at BEFORE UPDATE ON public.core_focus
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_ten_year_target_updated_at BEFORE UPDATE ON public.ten_year_target
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_marketing_strategy_updated_at BEFORE UPDATE ON public.marketing_strategy
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_three_year_picture_updated_at BEFORE UPDATE ON public.three_year_picture
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_one_year_plan_updated_at BEFORE UPDATE ON public.one_year_plan
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_quarterly_plan_updated_at BEFORE UPDATE ON public.quarterly_plan
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_company_rocks_updated_at BEFORE UPDATE ON public.company_rocks
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_individual_rocks_updated_at BEFORE UPDATE ON public.individual_rocks
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_team_members_updated_at BEFORE UPDATE ON public.team_members
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
