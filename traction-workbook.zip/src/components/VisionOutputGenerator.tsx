import React, { useState } from 'react';
import { 
  Paper, 
  Typography, 
  Box, 
  Button, 
  Tabs, 
  Tab, 
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert
} from '@mui/material';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import DashboardIcon from '@mui/icons-material/Dashboard';
import DownloadIcon from '@mui/icons-material/Download';
import PreviewIcon from '@mui/icons-material/Preview';

// This would be replaced with actual PDF generation
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`output-tabpanel-${index}`}
      aria-labelledby={`output-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

interface VisionOutputGeneratorProps {
  companyId: string;
  companyName: string;
  visionData: {
    coreValues?: any[];
    coreFocus?: any;
    tenYearTarget?: any;
    marketingStrategy?: any;
    threeYearPicture?: any;
    oneYearPlan?: any;
    quarterlyPlan?: any;
    companyRocks?: any[];
    individualRocks?: any[];
  };
}

const VisionOutputGenerator: React.FC<VisionOutputGeneratorProps> = ({ 
  companyId, 
  companyName,
  visionData 
}) => {
  const [tabValue, setTabValue] = useState(0);
  const [loading, setLoading] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewContent, setPreviewContent] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };
  
  const generateVTOPdf = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Create a new PDF document
      const doc = new jsPDF();
      
      // Add company name as title
      doc.setFontSize(20);
      doc.text(`${companyName} - Vision/Traction Organizer™ (V/TO™)`, 105, 15, { align: 'center' });
      
      // Add date
      doc.setFontSize(10);
      doc.text(`Generated on ${new Date().toLocaleDateString()}`, 105, 22, { align: 'center' });
      
      doc.setFontSize(12);
      let yPos = 30;
      
      // Core Values
      if (visionData.coreValues && visionData.coreValues.length > 0) {
        doc.setFontSize(16);
        doc.text('Core Values', 14, yPos);
        yPos += 8;
        
        doc.setFontSize(12);
        visionData.coreValues.forEach((value, index) => {
          doc.text(`${index + 1}. ${value.value_name}`, 14, yPos);
          yPos += 6;
          
          if (value.description) {
            doc.setFontSize(10);
            const descLines = doc.splitTextToSize(value.description, 180);
            doc.text(descLines, 20, yPos);
            yPos += 6 * descLines.length;
            doc.setFontSize(12);
          }
          
          if (value.behaviors && value.behaviors.length > 0) {
            doc.setFontSize(10);
            doc.text('Behaviors:', 20, yPos);
            yPos += 5;
            
            value.behaviors.forEach((behavior: string, i: number) => {
              if (behavior.trim()) {
                const behaviorLines = doc.splitTextToSize(`• ${behavior}`, 170);
                doc.text(behaviorLines, 25, yPos);
                yPos += 5 * behaviorLines.length;
              }
            });
            
            doc.setFontSize(12);
            yPos += 3;
          }
        });
      }
      
      // Check if we need a new page
      if (yPos > 250) {
        doc.addPage();
        yPos = 20;
      }
      
      // Core Focus
      if (visionData.coreFocus) {
        doc.setFontSize(16);
        doc.text('Core Focus', 14, yPos);
        yPos += 8;
        
        doc.setFontSize(12);
        if (visionData.coreFocus.purpose) {
          doc.text('Purpose/Cause/Passion:', 14, yPos);
          yPos += 6;
          
          doc.setFontSize(10);
          const purposeLines = doc.splitTextToSize(visionData.coreFocus.purpose, 180);
          doc.text(purposeLines, 20, yPos);
          yPos += 6 * purposeLines.length;
          doc.setFontSize(12);
        }
        
        yPos += 3;
        
        if (visionData.coreFocus.niche) {
          doc.text('Niche:', 14, yPos);
          yPos += 6;
          
          doc.setFontSize(10);
          const nicheLines = doc.splitTextToSize(visionData.coreFocus.niche, 180);
          doc.text(nicheLines, 20, yPos);
          yPos += 6 * nicheLines.length;
          doc.setFontSize(12);
        }
        
        yPos += 5;
      }
      
      // Check if we need a new page
      if (yPos > 250) {
        doc.addPage();
        yPos = 20;
      }
      
      // 10-Year Target
      if (visionData.tenYearTarget) {
        doc.setFontSize(16);
        doc.text('10-Year Target', 14, yPos);
        yPos += 8;
        
        doc.setFontSize(12);
        if (visionData.tenYearTarget.target_description) {
          const targetLines = doc.splitTextToSize(visionData.tenYearTarget.target_description, 180);
          doc.text(targetLines, 14, yPos);
          yPos += 6 * targetLines.length;
        }
        
        if (visionData.tenYearTarget.target_date) {
          doc.text(`Target Date: ${new Date(visionData.tenYearTarget.target_date).toLocaleDateString()}`, 14, yPos);
          yPos += 6;
        }
        
        yPos += 5;
      }
      
      // Check if we need a new page
      if (yPos > 250) {
        doc.addPage();
        yPos = 20;
      }
      
      // Marketing Strategy
      if (visionData.marketingStrategy) {
        doc.setFontSize(16);
        doc.text('Marketing Strategy', 14, yPos);
        yPos += 8;
        
        doc.setFontSize(12);
        if (visionData.marketingStrategy.target_market) {
          doc.text('Target Market:', 14, yPos);
          yPos += 6;
          
          doc.setFontSize(10);
          const marketLines = doc.splitTextToSize(visionData.marketingStrategy.target_market, 180);
          doc.text(marketLines, 20, yPos);
          yPos += 6 * marketLines.length;
          doc.setFontSize(12);
        }
        
        yPos += 3;
        
        if (visionData.marketingStrategy.uniques && visionData.marketingStrategy.uniques.length > 0) {
          doc.text('Three Uniques:', 14, yPos);
          yPos += 6;
          
          doc.setFontSize(10);
          visionData.marketingStrategy.uniques.forEach((unique: string, i: number) => {
            if (unique.trim()) {
              const uniqueLines = doc.splitTextToSize(`${i + 1}. ${unique}`, 175);
              doc.text(uniqueLines, 20, yPos);
              yPos += 6 * uniqueLines.length;
            }
          });
          doc.setFontSize(12);
        }
        
        yPos += 3;
        
        if (visionData.marketingStrategy.proven_process) {
          doc.text('Proven Process:', 14, yPos);
          yPos += 6;
          
          doc.setFontSize(10);
          const processLines = doc.splitTextToSize(visionData.marketingStrategy.proven_process, 180);
          doc.text(processLines, 20, yPos);
          yPos += 6 * processLines.length;
          doc.setFontSize(12);
        }
        
        yPos += 3;
        
        if (visionData.marketingStrategy.guarantee) {
          doc.text('Guarantee:', 14, yPos);
          yPos += 6;
          
          doc.setFontSize(10);
          const guaranteeLines = doc.splitTextToSize(visionData.marketingStrategy.guarantee, 180);
          doc.text(guaranteeLines, 20, yPos);
          yPos += 6 * guaranteeLines.length;
          doc.setFontSize(12);
        }
        
        yPos += 5;
      }
      
      // Check if we need a new page
      if (yPos > 250) {
        doc.addPage();
        yPos = 20;
      }
      
      // 3-Year Picture
      if (visionData.threeYearPicture) {
        doc.setFontSize(16);
        doc.text('3-Year Picture', 14, yPos);
        yPos += 8;
        
        doc.setFontSize(12);
        if (visionData.threeYearPicture.future_date) {
          doc.text(`Future Date: ${new Date(visionData.threeYearPicture.future_date).toLocaleDateString()}`, 14, yPos);
          yPos += 6;
        }
        
        if (visionData.threeYearPicture.revenue) {
          doc.text(`Revenue: $${visionData.threeYearPicture.revenue}`, 14, yPos);
          yPos += 6;
        }
        
        if (visionData.threeYearPicture.profit) {
          doc.text(`Profit: $${visionData.threeYearPicture.profit}`, 14, yPos);
          yPos += 6;
        }
        
        if (visionData.threeYearPicture.measurables && Object.keys(visionData.threeYearPicture.measurables).length > 0) {
          doc.text('Other Measurables:', 14, yPos);
          yPos += 6;
          
          doc.setFontSize(10);
          Object.entries(visionData.threeYearPicture.measurables).forEach(([key, value]) => {
            doc.text(`${key}: ${value}`, 20, yPos);
            yPos += 5;
          });
          doc.setFontSize(12);
        }
        
        yPos += 3;
        
        if (visionData.threeYearPicture.future_state) {
          doc.text('Future State:', 14, yPos);
          yPos += 6;
          
          doc.setFontSize(10);
          const stateLines = doc.splitTextToSize(visionData.threeYearPicture.future_state, 180);
          doc.text(stateLines, 20, yPos);
          yPos += 6 * stateLines.length;
          doc.setFontSize(12);
        }
        
        yPos += 5;
      }
      
      // Check if we need a new page
      if (yPos > 250) {
        doc.addPage();
        yPos = 20;
      }
      
      // 1-Year Plan
      if (visionData.oneYearPlan) {
        doc.setFontSize(16);
        doc.text('1-Year Plan', 14, yPos);
        yPos += 8;
        
        doc.setFontSize(12);
        if (visionData.oneYearPlan.future_date) {
          doc.text(`Future Date: ${new Date(visionData.oneYearPlan.future_date).toLocaleDateString()}`, 14, yPos);
          yPos += 6;
        }
        
        if (visionData.oneYearPlan.revenue_goal) {
          doc.text(`Revenue Goal: $${visionData.oneYearPlan.revenue_goal}`, 14, yPos);
          yPos += 6;
        }
        
        if (visionData.oneYearPlan.profit_goal) {
          doc.text(`Profit Goal: $${visionData.oneYearPlan.profit_goal}`, 14, yPos);
          yPos += 6;
        }
        
        if (visionData.oneYearPlan.goals && visionData.oneYearPlan.goals.length > 0) {
          doc.text('Goals:', 14, yPos);
          yPos += 6;
          
          doc.setFontSize(10);
          visionData.oneYearPlan.goals.forEach((goal: string, i: number) => {
            if (goal.trim()) {
              const goalLines = doc.splitTextToSize(`${i + 1}. ${goal}`, 175);
              doc.text(goalLines, 20, yPos);
              yPos += 6 * goalLines.length;
            }
          });
          doc.setFontSize(12);
        }
        
        yPos += 5;
      }
      
      // Check if we need a new page
      if (yPos > 250) {
        doc.addPage();
        yPos = 20;
      }
      
      // Quarterly Rocks
      if (visionData.quarterlyPlan) {
        doc.setFontSize(16);
        doc.text('Quarterly Rocks', 14, yPos);
        yPos += 8;
        
        doc.setFontSize(12);
        if (visionData.quarterlyPlan.quarter_name) {
          doc.text(`Quarter: ${visionData.quarterlyPlan.quarter_name}`, 14, yPos);
          yPos += 6;
        }
        
        if (visionData.quarterlyPlan.start_date && visionData.quarterlyPlan.end_date) {
          doc.text(`Date Range: ${new Date(visionData.quarterlyPlan.start_date).toLocaleDateString()} to ${new Date(visionData.quarterlyPlan.end_date).toLocaleDateString()}`, 14, yPos);
          yPos += 8;
        }
        
        if (visionData.companyRocks && visionData.companyRocks.length > 0) {
          doc.text('Company Rocks:', 14, yPos);
          yPos += 6;
          
          doc.setFontSize(10);
          visionData.companyRocks.forEach((rock, i) => {
            const rockLines = doc.splitTextToSize(`${i + 1}. ${rock.rock_description}`, 175);
            doc.text(rockLines, 20, yPos);
            yPos += 6 * rockLines.length;
            
            if (rock.measurable) {
              const measurableLines = doc.splitTextToSize(`Measurable: ${rock.measurable}`, 170);
              doc.text(measurableLines, 25, yPos);
              yPos += 5 * measurableLines.length;
            }
            
            doc.text(`Status: ${rock.status}`, 25, yPos);
            yPos += 5;
          });
          doc.setFontSize(12);
          yPos += 3;
        }
        
        // Check if we need a new page
        if (yPos > 250 && visionData.individualRocks && visionData.individualRocks.length > 0) {
          doc.addPage();
          yPos = 20;
        }
        
        if (visionData.individualRocks && visionData.individualRocks.length > 0) {
          doc.text('Individual Rocks:', 14, yPos);
          yPos += 6;
          
          doc.setFontSize(10);
          visionData.individualRocks.forEach((rock, i) => {
            const rockLines = doc.splitTextToSize(`${i + 1}. ${rock.rock_description}`, 175);
            doc.text(rockLines, 20, yPos);
            yPos += 6 * rockLines.length;
            
            if (rock.measurable) {
              const measurableLines = doc.splitTextToSize(`Measurable: ${rock.measurable}`, 170);
              doc.text(measurableLines, 25, yPos);
              yPos += 5 * measurableLines.length;
            }
            
            doc.text(`Owner: ${rock.owner_name || 'Unassigned'}`, 25, yPos);
            yPos += 5;
            
            doc.text(`Status: ${rock.status}`, 25, yPos);
            yPos += 8;
          });
          doc.setFontSize(12);
        }
      }
      
      // Add footer with page numbers
      const pageCount = doc.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(10);
        doc.text(`Page ${i} of ${pageCount}`, 105, 290, { align: 'center' });
      }
      
      // For preview, convert to data URL
      const pdfDataUrl = doc.output('datauristring');
      setPreviewContent(pdfDataUrl);
      
      return doc;
    } catch (err: any) {
      console.error('Error generating PDF:', err);
      setError(`Failed to generate PDF: ${err.message}`);
      return null;
    } finally {
      setLoading(false);
    }
  };
  
  const handlePreviewPdf = async () => {
    const doc = await generateVTOPdf();
    if (doc) {
      setPreviewOpen(true);
    }
  };
  
  const handleDownloadPdf = async () => {
    const doc = await generateVTOPdf();
    if (doc) {
      doc.save(`${companyName.replace(/\s+/g, '_')}_VTO.pdf`);
    }
  };
  
  const handleClosePreview = () => {
    setPreviewOpen(false);
  };
  
  return (
    <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
      <Typography variant="h5" gutterBottom>
        Output Generation
      </Typography>
      
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs value={tabValue} onChange={handleTabChange} aria-label="output tabs">
          <Tab 
            icon={<PictureAsPdfIcon />} 
            iconPosition="start" 
            label="PDF Documents" 
            id="output-tab-0" 
            aria-controls="output-tabpanel-0" 
          />
          <Tab 
            icon={<DashboardIcon />} 
            iconPosition="start" 
            label="Interactive Dashboard" 
            id="output-tab-1" 
            aria-controls="output-tabpanel-1" 
          />
        </Tabs>
      </Box>
      
      <TabPanel value={tabValue} index={0}>
        <Typography variant="body1" paragraph>
          Generate professional PDF documents based on your Vision component data. These documents can be shared with your team or used in presentations.
        </Typography>
        
        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}
        
        <Box display="flex" gap={2}>
          <Button
            variant="outlined"
            startIcon={<PreviewIcon />}
            onClick={handlePreviewPdf}
            disabled={loading}
          >
            Preview V/TO™
          </Button>
          
          <Button
            variant="contained"
            startIcon={loading ? <CircularProgress size={20} color="inherit" /> : <DownloadIcon />}
            onClick={handleDownloadPdf}
            disabled={loading}
          >
            {loading ? 'Generating...' : 'Download V/TO™ PDF'}
          </Button>
        </Box>
      </TabPanel>
      
      <TabPanel value={tabValue} index={1}>
        <Typography variant="body1" paragraph>
          View your Vision component data in an interactive dashboard. This dashboard provides a visual representation of your progress and helps you track your goals.
        </Typography>
        
        <Box sx={{ p: 3, bgcolor: '#f5f5f5', borderRadius: 2, textAlign: 'center' }}>
          <Typography variant="h6" gutterBottom>
            Vision Dashboard
          </Typography>
          
          <Typography variant="body2" color="text.secondary">
            The interactive dashboard is available in the Vision Dashboard section.
          </Typography>
          
          <Button
            variant="contained"
            onClick={() => window.location.href = `/companies/${companyId}/vision`}
            sx={{ mt: 2 }}
          >
            Go to Vision Dashboard
          </Button>
        </Box>
      </TabPanel>
      
      <Dialog
        open={previewOpen}
        onClose={handleClosePreview}
        maxWidth="lg"
        fullWidth
      >
        <DialogTitle>
          PDF Preview
        </DialogTitle>
        <DialogContent>
          {previewContent && (
            <iframe
              src={previewContent}
              style={{ width: '100%', height: '70vh', border: 'none' }}
              title="PDF Preview"
            />
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClosePreview}>Close</Button>
          <Button 
            variant="contained" 
            color="primary" 
            onClick={handleDownloadPdf}
            startIcon={<DownloadIcon />}
          >
            Download
          </Button>
        </DialogActions>
      </Dialog>
    </Paper>
  );
};

export default VisionOutputGenerator;
