import React, { useState } from 'react';
import { 
  Paper, 
  Typography, 
  Box, 
  IconButton, 
  Collapse, 
  Divider,
  CircularProgress,
  TextField,
  Button,
  List,
  ListItem,
  ListItemText,
  ListItemIcon
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import LightbulbIcon from '@mui/icons-material/Lightbulb';
import SendIcon from '@mui/icons-material/Send';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

// This would be replaced with actual API calls to an AI provider
const mockAIResponses = {
  'Vision': {
    'Core Values': [
      "Core values should be authentic to your organization, not aspirational. Think about what truly makes your company unique.",
      "Limit your core values to 3-7 meaningful principles. Too many dilutes their impact.",
      "For each core value, define specific behaviors that demonstrate that value in action.",
      "Consider involving your leadership team in identifying core values for broader perspective.",
      "Test potential core values by asking if you'd hold to them even if they became a competitive disadvantage."
    ],
    'Core Focus': [
      "Your purpose/cause/passion answers WHY your company exists beyond making money.",
      "Your niche defines WHAT you do better than anyone else in the world.",
      "Keep your Core Focus simple and memorable - ideally just a few words for each part.",
      "A strong Core Focus helps you say 'no' to opportunities that don't align with your purpose and niche.",
      "Your Core Focus should remain relatively stable over time, unlike your marketing strategy or goals."
    ],
    '10-Year Target': [
      "Your 10-Year Target should be ambitious but achievable - a 'Big Hairy Audacious Goal' that inspires your team.",
      "Make it specific and measurable so you'll know when you've achieved it.",
      "The best 10-Year Targets are simple and easy to memorize.",
      "Consider both quantitative metrics (revenue, customers) and qualitative achievements.",
      "Your 10-Year Target should align with your Core Focus and Core Values."
    ],
    'Marketing Strategy': [
      "Your Target Market should be specific - 'everyone' is not a target market.",
      "Your Three Uniques are the combination of attributes that make you different from competitors.",
      "Your Proven Process shows clients how you deliver your product or service consistently.",
      "A strong Guarantee reduces the perceived risk for your customers.",
      "Your Marketing Strategy should be simple enough that everyone in your company can understand and communicate it."
    ],
    '3-Year Picture': [
      "Your 3-Year Picture should be a clear, detailed vision of what your company will look like three years from now.",
      "Include specific, measurable targets for revenue, profit, and other key metrics.",
      "Consider what your team, facilities, geographic reach, and product/service offerings will look like.",
      "Your 3-Year Picture should be ambitious but realistic - a stretch but achievable with focus and effort.",
      "Make sure your 3-Year Picture aligns with and supports your 10-Year Target."
    ],
    '1-Year Plan': [
      "Your 1-Year Plan should include 3-7 specific, measurable goals that move you toward your 3-Year Picture.",
      "Each goal should be SMART: Specific, Measurable, Achievable, Relevant, and Time-bound.",
      "Include both financial goals (revenue, profit) and non-financial goals (new products, hiring, etc.).",
      "Your 1-Year Plan should be challenging but realistic - ambitious enough to stretch but achievable with focus.",
      "Review your 1-Year Plan quarterly to track progress and make adjustments as needed."
    ],
    'Quarterly Rocks': [
      "Rocks are the 3-7 most important priorities for your company to accomplish in the next 90 days.",
      "Each Rock should be specific, measurable, and achievable within the quarter.",
      "Assign clear ownership for each Rock to ensure accountability.",
      "Individual Rocks (1-3 per person) should align with and support Company Rocks.",
      "Review Rocks weekly to track progress and address obstacles early."
    ]
  }
};

const AICoachingPanel = ({ component, exercise, onClose }) => {
  const [loading, setLoading] = useState(false);
  const [question, setQuestion] = useState('');
  const [conversation, setConversation] = useState([]);
  
  // Get coaching tips based on component and exercise
  const getTips = () => {
    if (mockAIResponses[component] && mockAIResponses[component][exercise]) {
      return mockAIResponses[component][exercise];
    }
    return ["No specific tips available for this exercise."];
  };
  
  const handleAskQuestion = async () => {
    if (!question.trim()) return;
    
    // Add user question to conversation
    setConversation([...conversation, { role: 'user', content: question }]);
    
    // Clear input field
    setQuestion('');
    
    // Show loading state
    setLoading(true);
    
    try {
      // In a real implementation, this would be an API call to an AI provider
      // For now, we'll simulate a delay and provide a mock response
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Generate a contextual response based on the exercise
      let aiResponse = `Based on the ${exercise} exercise, `;
      
      if (question.toLowerCase().includes('example')) {
        aiResponse += getExampleResponse(exercise);
      } else if (question.toLowerCase().includes('how') || question.toLowerCase().includes('what')) {
        aiResponse += getHowToResponse(exercise);
      } else {
        aiResponse += getGeneralResponse(exercise);
      }
      
      // Add AI response to conversation
      setConversation([...conversation, 
        { role: 'user', content: question },
        { role: 'assistant', content: aiResponse }
      ]);
    } catch (error) {
      console.error('Error getting AI response:', error);
      // Add error message to conversation
      setConversation([...conversation, 
        { role: 'user', content: question },
        { role: 'assistant', content: 'Sorry, I encountered an error while processing your question. Please try again.' }
      ]);
    } finally {
      setLoading(false);
    }
  };
  
  // Mock response generators based on exercise type
  const getExampleResponse = (exercise) => {
    switch (exercise) {
      case 'Core Values':
        return "here are some examples of strong core values: 'Integrity' (We do what we say we'll do), 'Innovation' (We constantly seek better ways to solve problems), 'Customer Focus' (We make decisions based on what's best for our customers).";
      case 'Core Focus':
        return "for a marketing agency, a good Core Focus might be Purpose: 'To help businesses tell their stories effectively' and Niche: 'Data-driven creative marketing for B2B tech companies'.";
      case '10-Year Target':
        return "a compelling 10-Year Target might be 'To become a $100 million company with offices in 10 major cities' or 'To impact the lives of 1 million customers with our product'.";
      case 'Marketing Strategy':
        return "for a premium coffee shop, the Target Market might be 'Urban professionals aged 25-45 who value quality and experience', and Uniques might include 'Single-origin beans', 'Barista education program', and 'Sustainable sourcing with direct farmer relationships'.";
      case '3-Year Picture':
        return "a well-defined 3-Year Picture might include 'Revenue of $5M', 'Team of 25 employees', '3 office locations', and 'Launch of 2 new product lines'.";
      case '1-Year Plan':
        return "effective 1-Year Plan goals might include 'Increase revenue to $2.5M', 'Hire 5 new team members in key roles', 'Launch new customer portal', and 'Achieve 90% customer retention rate'.";
      case 'Quarterly Rocks':
        return "good Quarterly Rocks might include 'Complete new website launch', 'Hire and onboard new sales director', and 'Implement new CRM system with 100% team adoption'.";
      default:
        return "I can provide specific examples tailored to your business if you share more details about your company.";
    }
  };
  
  const getHowToResponse = (exercise) => {
    switch (exercise) {
      case 'Core Values':
        return "to identify your Core Values, gather your leadership team and discuss: What behaviors do you value most? What characteristics do your best employees share? What principles would you maintain even if they became a competitive disadvantage?";
      case 'Core Focus':
        return "to determine your Core Focus, ask: Why does your organization exist beyond making money? What are you truly passionate about? What can you be the best in the world at?";
      case '10-Year Target':
        return "to create your 10-Year Target, envision where you want your company to be in 10 years. Make it specific, measurable, and ambitious yet achievable. It should inspire your team and provide clear direction.";
      case 'Marketing Strategy':
        return "to develop your Marketing Strategy, first clearly define your ideal customer. Then identify what makes you different from competitors. Document your delivery process, and consider what guarantee you can offer to reduce customer risk.";
      case '3-Year Picture':
        return "to build your 3-Year Picture, work backward from your 10-Year Target. What needs to be true in 3 years to be on track? Include specific metrics for revenue, profit, team size, and other key indicators.";
      case '1-Year Plan':
        return "to create your 1-Year Plan, identify 3-7 most important goals that will move you toward your 3-Year Picture. Make each goal SMART (Specific, Measurable, Achievable, Relevant, Time-bound).";
      case 'Quarterly Rocks':
        return "to set effective Quarterly Rocks, identify the 3-7 most important priorities that will move you toward your 1-Year Plan in the next 90 days. Assign clear ownership and ensure each Rock is specific and measurable.";
      default:
        return "I can provide specific guidance if you share more details about what aspect of this exercise you're struggling with.";
    }
  };
  
  const getGeneralResponse = (exercise) => {
    switch (exercise) {
      case 'Core Values':
        return "remember that Core Values should be authentic, not aspirational. They should reflect who you truly are as an organization, not who you want to be. The best Core Values are clear, meaningful, and actionable.";
      case 'Core Focus':
        return "your Core Focus helps you stay focused on what you do best. It should be simple, clear, and memorable. Use it as a filter for opportunities - if something doesn't align with your Core Focus, it's probably a distraction.";
      case '10-Year Target':
        return "your 10-Year Target should be ambitious enough to inspire but realistic enough to be believable. It provides long-term direction and helps align your team around a common goal.";
      case 'Marketing Strategy':
        return "a clear Marketing Strategy helps you attract the right customers and stand out from competitors. Keep it simple and ensure everyone in your organization can understand and communicate it.";
      case '3-Year Picture':
        return "your 3-Year Picture bridges the gap between your long-term vision and short-term planning. It should be detailed enough that everyone can visualize what success looks like at that milestone.";
      case '1-Year Plan':
        return "your 1-Year Plan breaks down your longer-term vision into actionable annual goals. It provides clear direction for the year while remaining flexible enough to adapt to changing conditions.";
      case 'Quarterly Rocks':
        return "Quarterly Rocks create focus and accountability for the next 90 days. They help you make meaningful progress toward your annual goals by concentrating your efforts on the most important priorities.";
      default:
        return "I'm here to help you work through this exercise effectively. Feel free to ask specific questions about any challenges you're facing.";
    }
  };
  
  return (
    <Paper 
      elevation={3} 
      sx={{ 
        p: 3, 
        mb: 4, 
        position: 'relative',
        bgcolor: '#f8f9fa',
        border: '1px solid #e0e0e0',
        borderRadius: 2
      }}
    >
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h6" component="h3">
          AI Coaching: {exercise}
        </Typography>
        <IconButton onClick={onClose} size="small">
          <CloseIcon />
        </IconButton>
      </Box>
      
      <Divider sx={{ mb: 2 }} />
      
      <Typography variant="subtitle1" gutterBottom>
        Tips & Best Practices
      </Typography>
      
      <List dense>
        {getTips().map((tip, index) => (
          <ListItem key={index}>
            <ListItemIcon sx={{ minWidth: 36 }}>
              <LightbulbIcon color="primary" fontSize="small" />
            </ListItemIcon>
            <ListItemText primary={tip} />
          </ListItem>
        ))}
      </List>
      
      <Divider sx={{ my: 2 }} />
      
      <Typography variant="subtitle1" gutterBottom>
        Ask for Guidance
      </Typography>
      
      {conversation.length > 0 && (
        <Box mb={3} sx={{ maxHeight: 300, overflowY: 'auto', bgcolor: '#ffffff', p: 2, borderRadius: 1 }}>
          {conversation.map((message, index) => (
            <Box 
              key={index} 
              sx={{ 
                mb: 2, 
                display: 'flex',
                flexDirection: 'column',
                alignItems: message.role === 'user' ? 'flex-end' : 'flex-start'
              }}
            >
              <Paper 
                elevation={1} 
                sx={{ 
                  p: 1.5, 
                  maxWidth: '80%',
                  bgcolor: message.role === 'user' ? '#e3f2fd' : '#f1f8e9',
                  borderRadius: 2
                }}
              >
                <Typography variant="body2">{message.content}</Typography>
              </Paper>
            </Box>
          ))}
        </Box>
      )}
      
      <Box display="flex" alignItems="center">
        <TextField
          fullWidth
          size="small"
          variant="outlined"
          placeholder="Ask a question about this exercise..."
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleAskQuestion()}
          disabled={loading}
          sx={{ mr: 1 }}
        />
        <Button
          variant="contained"
          color="primary"
          endIcon={loading ? <CircularProgress size={20} color="inherit" /> : <SendIcon />}
          onClick={handleAskQuestion}
          disabled={loading || !question.trim()}
        >
          {loading ? 'Thinking...' : 'Ask'}
        </Button>
      </Box>
    </Paper>
  );
};

export default AICoachingPanel;
