import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { visionDb } from '../../lib/supabase';
import { 
  Button, 
  Container, 
  Typography, 
  Box, 
  Grid, 
  TextField, 
  IconButton, 
  Paper,
  Divider,
  Alert,
  Snackbar,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Tabs,
  Tab
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import SaveIcon from '@mui/icons-material/Save';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import AICoachingPanel from '../../components/AICoachingPanel';
import { addMonths } from 'date-fns';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`rocks-tabpanel-${index}`}
      aria-labelledby={`rocks-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

const QuarterlyRocks = () => {
  const { companyId } = useParams<{ companyId: string }>();
  const navigate = useNavigate();
  
  const [tabValue, setTabValue] = useState(0);
  const [quarterlyPlan, setQuarterlyPlan] = useState<any>({
    quarter_name: `Q${Math.floor((new Date().getMonth() / 3)) + 1} ${new Date().getFullYear()}`,
    start_date: new Date(),
    end_date: addMonths(new Date(), 3)
  });
  const [companyRocks, setCompanyRocks] = useState<any[]>([]);
  const [individualRocks, setIndividualRocks] = useState<any[]>([]);
  const [teamMembers, setTeamMembers] = useState<any[]>([]);
  const [newCompanyRock, setNewCompanyRock] = useState({ rock_description: '', measurable: '', owner_id: '', status: 'on-track' });
  const [newIndividualRock, setNewIndividualRock] = useState({ rock_description: '', measurable: '', owner_id: '', status: 'on-track' });
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showCoaching, setShowCoaching] = useState(false);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'success' });
  
  useEffect(() => {
    if (companyId) {
      fetchQuarterlyPlan();
      fetchTeamMembers();
    }
  }, [companyId]);
  
  const fetchQuarterlyPlan = async () => {
    setLoading(true);
    try {
      const { data, error } = await visionDb.getQuarterlyPlan(companyId as string);
      
      if (error) {
        if (error.code === 'PGRST116') {
          // No data found, this is fine for a new company
          const currentQuarter = Math.floor((new Date().getMonth() / 3)) + 1;
          const currentYear = new Date().getFullYear();
          
          setQuarterlyPlan({
            quarter_name: `Q${currentQuarter} ${currentYear}`,
            start_date: new Date(),
            end_date: addMonths(new Date(), 3)
          });
          
          setCompanyRocks([]);
          setIndividualRocks([]);
        } else {
          throw error;
        }
      } else if (data) {
        // Convert date strings to Date objects
        const updatedData = {
          ...data,
          start_date: data.start_date ? new Date(data.start_date) : new Date(),
          end_date: data.end_date ? new Date(data.end_date) : addMonths(new Date(), 3)
        };
        
        setQuarterlyPlan(updatedData);
        
        // Fetch company rocks and individual rocks
        await fetchCompanyRocks(data.id);
        await fetchIndividualRocks(data.id);
      }
    } catch (error: any) {
      console.error('Error fetching quarterly plan:', error.message);
      setNotification({
        open: true,
        message: 'Failed to load quarterly plan. Please try again.',
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };
  
  const fetchCompanyRocks = async (quarterlyPlanId: string) => {
    try {
      const { data, error } = await visionDb.getCompanyRocks(quarterlyPlanId);
      
      if (error) {
        throw error;
      }
      
      setCompanyRocks(data || []);
    } catch (error: any) {
      console.error('Error fetching company rocks:', error.message);
    }
  };
  
  const fetchIndividualRocks = async (quarterlyPlanId: string) => {
    try {
      const { data, error } = await visionDb.getIndividualRocks(quarterlyPlanId);
      
      if (error) {
        throw error;
      }
      
      setIndividualRocks(data || []);
    } catch (error: any) {
      console.error('Error fetching individual rocks:', error.message);
    }
  };
  
  const fetchTeamMembers = async () => {
    try {
      const { data, error } = await visionDb.getTeamMembers(companyId as string);
      
      if (error) {
        throw error;
      }
      
      setTeamMembers(data || []);
    } catch (error: any) {
      console.error('Error fetching team members:', error.message);
    }
  };
  
  const handleSaveQuarterlyPlan = async () => {
    if (!quarterlyPlan.quarter_name.trim()) {
      setNotification({
        open: true,
        message: 'Please enter a quarter name before saving.',
        severity: 'warning'
      });
      return;
    }
    
    setSaving(true);
    try {
      let result;
      
      if (quarterlyPlan.id) {
        // Update existing quarterly plan
        result = await visionDb.updateQuarterlyPlan(quarterlyPlan.id, {
          quarter_name: quarterlyPlan.quarter_name,
          start_date: quarterlyPlan.start_date,
          end_date: quarterlyPlan.end_date
        });
      } else {
        // Create new quarterly plan
        result = await visionDb.createQuarterlyPlan({
          company_id: companyId,
          quarter_name: quarterlyPlan.quarter_name,
          start_date: quarterlyPlan.start_date,
          end_date: quarterlyPlan.end_date
        });
      }
      
      if (result.error) {
        throw result.error;
      }
      
      // Update state with the returned data
      if (result.data && result.data[0]) {
        setQuarterlyPlan({
          ...result.data[0],
          start_date: result.data[0].start_date ? new Date(result.data[0].start_date) : new Date(),
          end_date: result.data[0].end_date ? new Date(result.data[0].end_date) : addMonths(new Date(), 3)
        });
      }
      
      setNotification({
        open: true,
        message: 'Quarterly plan saved successfully!',
        severity: 'success'
      });
    } catch (error: any) {
      console.error('Error saving quarterly plan:', error.message);
      setNotification({
        open: true,
        message: 'Failed to save quarterly plan. Please try again.',
        severity: 'error'
      });
    } finally {
      setSaving(false);
    }
  };
  
  const handleAddCompanyRock = async () => {
    if (!newCompanyRock.rock_description.trim()) {
      setNotification({
        open: true,
        message: 'Please enter a rock description before adding.',
        severity: 'warning'
      });
      return;
    }
    
    if (!quarterlyPlan.id) {
      setNotification({
        open: true,
        message: 'Please save the quarterly plan first.',
        severity: 'warning'
      });
      return;
    }
    
    try {
      const { data, error } = await visionDb.createCompanyRock({
        quarterly_plan_id: quarterlyPlan.id,
        rock_description: newCompanyRock.rock_description,
        measurable: newCompanyRock.measurable,
        owner_id: newCompanyRock.owner_id || null,
        status: newCompanyRock.status,
        order_num: companyRocks.length + 1
      });
      
      if (error) {
        throw error;
      }
      
      // Update state with the returned data
      if (data && data[0]) {
        setCompanyRocks([...companyRocks, data[0]]);
        setNewCompanyRock({ rock_description: '', measurable: '', owner_id: '', status: 'on-track' });
      }
      
      setNotification({
        open: true,
        message: 'Company rock added successfully!',
        severity: 'success'
      });
    } catch (error: any) {
      console.error('Error adding company rock:', error.message);
      setNotification({
        open: true,
        message: 'Failed to add company rock. Please try again.',
        severity: 'error'
      });
    }
  };
  
  const handleAddIndividualRock = async () => {
    if (!newIndividualRock.rock_description.trim()) {
      setNotification({
        open: true,
        message: 'Please enter a rock description before adding.',
        severity: 'warning'
      });
      return;
    }
    
    if (!newIndividualRock.owner_id) {
      setNotification({
        open: true,
        message: 'Please select a team member before adding.',
        severity: 'warning'
      });
      return;
    }
    
    if (!quarterlyPlan.id) {
      setNotification({
        open: true,
        message: 'Please save the quarterly plan first.',
        severity: 'warning'
      });
      return;
    }
    
    try {
      const { data, error } = await visionDb.createIndividualRock({
        quarterly_plan_id: quarterlyPlan.id,
        rock_description: newIndividualRock.rock_description,
        measurable: newIndividualRock.measurable,
        owner_id: newIndividualRock.owner_id,
        status: newIndividualRock.status
      });
      
      if (error) {
        throw error;
      }
      
      // Update state with the returned data
      if (data && data[0]) {
        setIndividualRocks([...individualRocks, data[0]]);
        setNewIndividualRock({ rock_description: '', measurable: '', owner_id: '', status: 'on-track' });
      }
      
      setNotification({
        open: true,
        message: 'Individual rock added successfully!',
        severity: 'success'
      });
    } catch (error: any) {
      console.error('Error adding individual rock:', error.message);
      setNotification({
        open: true,
        message: 'Failed to add individual rock. Please try again.',
        severity: 'error'
      });
    }
  };
  
  const handleUpdateCompanyRock = async (id: string, updates: any) => {
    try {
      const { error } = await visionDb.updateCompanyRock(id, updates);
      
      if (error) {
        throw error;
      }
      
      // Update state
      setCompanyRocks(companyRocks.map(rock => rock.id === id ? { ...rock, ...updates } : rock));
      
      setNotification({
        open: true,
        message: 'Company rock updated successfully!',
        severity: 'success'
      });
    } catch (error: any) {
      console.error('Error updating company rock:', error.message);
      setNotification({
        open: true,
        message: 'Failed to update company rock. Please try again.',
        severity: 'error'
      });
    }
  };
  
  const handleUpdateIndividualRock = async (id: string, updates: any) => {
    try {
      const { error } = await visionDb.updateIndividualRock(id, updates);
      
      if (error) {
        throw error;
      }
      
      // Update state
      setIndividualRocks(individualRocks.map(rock => rock.id === id ? { ...rock, ...updates } : rock));
      
      setNotification({
        open: true,
        message: 'Individual rock updated successfully!',
        severity: 'success'
      });
    } catch (error: any) {
      console.error('Error updating individual rock:', error.message);
      setNotification({
        open: true,
        message: 'Failed to update individual rock. Please try again.',
        severity: 'error'
      });
    }
  };
  
  const handleDeleteCompanyRock = async (id: string) => {
    try {
      const { error } = await visionDb.deleteCompanyRock(id);
      
      if (error) {
        throw error;
      }
      
      // Update state
      setCompanyRocks(companyRocks.filter(rock => rock.id !== id));
      
      setNotification({
        open: true,
        message: 'Company rock deleted successfully!',
        severity: 'success'
      });
    } catch (error: any) {
      console.error('Error deleting company rock:', error.message);
      setNotification({
        open: true,
        message: 'Failed to delete company rock. Please try again.',
        severity: 'error'
      });
    }
  };
  
  const handleDeleteIndividualRock = async (id: string) => {
    try {
      const { error } = await visionDb.deleteIndividualRock(id);
      
      if (error) {
        throw error;
      }
      
      // Update state
      setIndividualRocks(individualRocks.filter(rock => rock.id !== id));
      
      setNotification({
        open: true,
        message: 'Individual rock deleted successfully!',
        severity: 'success'
      });
    } catch (error: any) {
      console.error('Error deleting individual rock:', error.message);
      setNotification({
        open: true,
        message: 'Failed to delete individual rock. Please try again.',
        severity: 'error'
      });
    }
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setQuarterlyPlan({ ...quarterlyPlan, [name]: value });
  };
  
  const handleStartDateChange = (newDate: Date | null) => {
    setQuarterlyPlan({ ...quarterlyPlan, start_date: newDate || new Date() });
  };
  
  const handleEndDateChange = (newDate: Date | null) => {
    setQuarterlyPlan({ ...quarterlyPlan, end_date: newDate || addMonths(new Date(), 3) });
  };
  
  const handleNewCompanyRockChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewCompanyRock({ ...newCompanyRock, [name]: value });
  };
  
  const handleNewIndividualRockChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewIndividualRock({ ...newIndividualRock, [name]: value });
  };
  
  const handleSelectChange = (e: any) => {
    const { name, value } = e.target;
    if (tabValue === 0) {
      setNewCompanyRock({ ...newCompanyRock, [name]: value });
    } else {
      setNewIndividualRock({ ...newIndividualRock, [name]: value });
    }
  };
  
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };
  
  const handleCloseNotification = () => {
    setNotification({ ...notification, open: false });
  };
  
  const getTeamMemberName = (id: string) => {
    const member = teamMembers.find(m => m.id === id);
    return member ? member.name : 'Unassigned';
  };
  
  return (
    <Container maxWidth="lg">
      <Box my={4}>
        <Typography variant="h4" component="h1" gutterBottom>
          Quarterly Rocks Exercise
          <IconButton 
            color="primary" 
            onClick={() => setShowCoaching(!showCoaching)}
            aria-label="Get AI coaching"
          >
            <HelpOutlineIcon />
          </IconButton>
        </Typography>
        
        <Typography variant="body1" paragraph>
          Rocks are the 3-7 most important priorities for your company and individuals to accomplish in the next 90 days. They are specific, measurable, and achievable goals that move you toward your 1-Year Plan.
        </Typography>
        
        {showCoaching && (
          <AICoachingPanel 
            component="Vision" 
            exercise="Quarterly Rocks" 
            onClose={() => setShowCoaching(false)}
          />
        )}
        
        <Divider sx={{ my: 3 }} />
        
        {loading ? (
          <Box display="flex" justifyContent="center" my={4}>
            <Typography>Loading quarterly rocks...</Typography>
          </Box>
        ) : (
          <>
            <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
              <Typography variant="h5" gutterBottom>
                Quarterly Plan
              </Typography>
              
              <Grid container spacing={3}>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    name="quarter_name"
                    label="Quarter Name"
                    value={quarterlyPlan.quarter_name || ''}
                    onChange={handleChange}
                    variant="outlined"
                    placeholder="e.g., Q2 2025"
                  />
                </Grid>
                
                <Grid item xs={12} md={4}>
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DatePicker
                      label="Start Date"
                      value={quarterlyPlan.start_date}
                      onChange={handleStartDateChange}
                      slotProps={{
                        textField: {
                          fullWidth: true,
                          variant: 'outlined'
                        }
                      }}
                    />
                  </LocalizationProvider>
                </Grid>
                
                <Grid item xs={12} md={4}>
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DatePicker
                      label="End Date"
                      value={quarterlyPlan.end_date}
                      onChange={handleEndDateChange}
                      slotProps={{
                        textField: {
                          fullWidth: true,
                          variant: 'outlined'
                        }
                      }}
                    />
                  </LocalizationProvider>
                </Grid>
                
                <Grid item xs={12} display="flex" justifyContent="flex-end">
                  <Button
                    startIcon={<SaveIcon />}
                    onClick={handleSaveQuarterlyPlan}
                    variant="contained"
                    color="primary"
                    disabled={saving}
                  >
                    {saving ? 'Saving...' : 'Save Quarterly Plan'}
                  </Button>
                </Grid>
              </Grid>
            </Paper>
            
            <Paper elevation={3} sx={{ mb: 4 }}>
              <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                <Tabs value={tabValue} onChange={handleTabChange} aria-label="rocks tabs">
                  <Tab label="Company Rocks" id="rocks-tab-0" aria-controls="rocks-tabpanel-0" />
                  <Tab label="Individual Rocks" id="rocks-tab-1" aria-controls="rocks-tabpanel-1" />
                </Tabs>
              </Box>
              
              <TabPanel value={tabValue} index={0}>
                <Typography variant="h6" gutterBottom>
                  Company Rocks
                </Typography>
                <Typography variant="body2" color="text.secondary" paragraph>
                  These are the 3-7 most important priorities for your company to accomplish this quarter.
                </Typography>
                
                {companyRocks.length > 0 ? (
                  <Box mb={4}>
                    {companyRocks.map((rock, index) => (
                      <Paper key={rock.id} elevation={2} sx={{ p: 2, mb: 2 }}>
                        <Grid container spacing={2}>
                          <Grid item xs={12} sm={6}>
                            <TextField
                              fullWidth
                              label="Rock Description"
                              value={rock.rock_description}
                              onChange={(e) => handleUpdateCompanyRock(rock.id, { rock_description: e.target.value })}
                              variant="outlined"
                              size="small"
                            />
                          </Grid>
                          
                          <Grid item xs={12} sm={6}>
                            <TextField
                              fullWidth
                              label="Measurable"
                              value={rock.measurable || ''}
                              onChange={(e) => handleUpdateCompanyRock(rock.id, { measurable: e.target.value })}
                              variant="outlined"
                              size="small"
                              placeholder="e.g., Increase sales by 15%"
                            />
                          </Grid>
                          
                          <Grid item xs={12} sm={6}>
                            <FormControl fullWidth size="small">
                              <InputLabel>Owner</InputLabel>
                              <Select
                                value={rock.owner_id || ''}
                                onChange={(e) => handleUpdateCompanyRock(rock.id, { owner_id: e.target.value })}
                                label="Owner"
                              >
                                <MenuItem value="">
                                  <em>Unassigned</em>
                                </MenuItem>
                                {teamMembers.map((member) => (
                                  <MenuItem key={member.id} value={member.id}>
                                    {member.name}
                                  </MenuItem>
                                ))}
                              </Select>
                            </FormControl>
                          </Grid>
                          
                          <Grid item xs={12} sm={6}>
                            <FormControl fullWidth size="small">
                              <InputLabel>Status</InputLabel>
                              <Select
                                value={rock.status || 'on-track'}
                                onChange={(e) => handleUpdateCompanyRock(rock.id, { status: e.target.value })}
                                label="Status"
                              >
                                <MenuItem value="on-track">On Track</MenuItem>
                                <MenuItem value="behind">Behind</MenuItem>
                                <MenuItem value="stuck">Stuck</MenuItem>
                                <MenuItem value="completed">Completed</MenuItem>
                              </Select>
                            </FormControl>
                          </Grid>
                          
                          <Grid item xs={12} display="flex" justifyContent="flex-end">
                            <Button
                              color="error"
                              onClick={() => handleDeleteCompanyRock(rock.id)}
                              startIcon={<DeleteIcon />}
                            >
                              Delete
                            </Button>
                          </Grid>
                        </Grid>
                      </Paper>
                    ))}
                  </Box>
                ) : (
                  <Alert severity="info" sx={{ mb: 3 }}>
                    No company rocks defined yet. Add your first rock below.
                  </Alert>
                )}
                
                <Paper elevation={2} sx={{ p: 2, mb: 2, bgcolor: 'background.default' }}>
                  <Typography variant="subtitle1" gutterBottom>
                    Add New Company Rock
                  </Typography>
                  
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        name="rock_description"
                        label="Rock Description"
                        value={newCompanyRock.rock_description}
                        onChange={handleNewCompanyRockChange}
                        variant="outlined"
                        size="small"
                        placeholder="e.g., Launch new marketing campaign"
                      />
                    </Grid>
                    
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        name="measurable"
                        label="Measurable"
                        value={newCompanyRock.measurable}
                        onChange={handleNewCompanyRockChange}
                        variant="outlined"
                        size="small"
                        placeholder="e.g., Generate 100 new leads"
                      />
                    </Grid>
                    
                    <Grid item xs={12} sm={6}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Owner</InputLabel>
                        <Select
                          name="owner_id"
                          value={newCompanyRock.owner_id}
                          onChange={handleSelectChange}
                          label="Owner"
                        >
                          <MenuItem value="">
                            <em>Unassigned</em>
                          </MenuItem>
                          {teamMembers.map((member) => (
                            <MenuItem key={member.id} value={member.id}>
                              {member.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Grid>
                    
                    <Grid item xs={12} sm={6}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Status</InputLabel>
                        <Select
                          name="status"
                          value={newCompanyRock.status}
                          onChange={handleSelectChange}
                          label="Status"
                        >
                          <MenuItem value="on-track">On Track</MenuItem>
                          <MenuItem value="behind">Behind</MenuItem>
                          <MenuItem value="stuck">Stuck</MenuItem>
                          <MenuItem value="completed">Completed</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                    
                    <Grid item xs={12} display="flex" justifyContent="flex-end">
                      <Button
                        startIcon={<AddIcon />}
                        onClick={handleAddCompanyRock}
                        variant="contained"
                        color="primary"
                        disabled={!quarterlyPlan.id}
                      >
                        Add Rock
                      </Button>
                    </Grid>
                  </Grid>
                </Paper>
                
                {!quarterlyPlan.id && (
                  <Alert severity="warning" sx={{ mt: 2 }}>
                    Please save the quarterly plan first before adding rocks.
                  </Alert>
                )}
              </TabPanel>
              
              <TabPanel value={tabValue} index={1}>
                <Typography variant="h6" gutterBottom>
                  Individual Rocks
                </Typography>
                <Typography variant="body2" color="text.secondary" paragraph>
                  These are the 1-3 most important priorities for each team member to accomplish this quarter.
                </Typography>
                
                {individualRocks.length > 0 ? (
                  <Box mb={4}>
                    {individualRocks.map((rock) => (
                      <Paper key={rock.id} elevation={2} sx={{ p: 2, mb: 2 }}>
                        <Grid container spacing={2}>
                          <Grid item xs={12}>
                            <Typography variant="subtitle1" gutterBottom>
                              Owner: {getTeamMemberName(rock.owner_id)}
                            </Typography>
                          </Grid>
                          
                          <Grid item xs={12} sm={6}>
                            <TextField
                              fullWidth
                              label="Rock Description"
                              value={rock.rock_description}
                              onChange={(e) => handleUpdateIndividualRock(rock.id, { rock_description: e.target.value })}
                              variant="outlined"
                              size="small"
                            />
                          </Grid>
                          
                          <Grid item xs={12} sm={6}>
                            <TextField
                              fullWidth
                              label="Measurable"
                              value={rock.measurable || ''}
                              onChange={(e) => handleUpdateIndividualRock(rock.id, { measurable: e.target.value })}
                              variant="outlined"
                              size="small"
                              placeholder="e.g., Complete 5 customer interviews"
                            />
                          </Grid>
                          
                          <Grid item xs={12} sm={6}>
                            <FormControl fullWidth size="small">
                              <InputLabel>Owner</InputLabel>
                              <Select
                                value={rock.owner_id}
                                onChange={(e) => handleUpdateIndividualRock(rock.id, { owner_id: e.target.value })}
                                label="Owner"
                              >
                                {teamMembers.map((member) => (
                                  <MenuItem key={member.id} value={member.id}>
                                    {member.name}
                                  </MenuItem>
                                ))}
                              </Select>
                            </FormControl>
                          </Grid>
                          
                          <Grid item xs={12} sm={6}>
                            <FormControl fullWidth size="small">
                              <InputLabel>Status</InputLabel>
                              <Select
                                value={rock.status || 'on-track'}
                                onChange={(e) => handleUpdateIndividualRock(rock.id, { status: e.target.value })}
                                label="Status"
                              >
                                <MenuItem value="on-track">On Track</MenuItem>
                                <MenuItem value="behind">Behind</MenuItem>
                                <MenuItem value="stuck">Stuck</MenuItem>
                                <MenuItem value="completed">Completed</MenuItem>
                              </Select>
                            </FormControl>
                          </Grid>
                          
                          <Grid item xs={12} display="flex" justifyContent="flex-end">
                            <Button
                              color="error"
                              onClick={() => handleDeleteIndividualRock(rock.id)}
                              startIcon={<DeleteIcon />}
                            >
                              Delete
                            </Button>
                          </Grid>
                        </Grid>
                      </Paper>
                    ))}
                  </Box>
                ) : (
                  <Alert severity="info" sx={{ mb: 3 }}>
                    No individual rocks defined yet. Add your first rock below.
                  </Alert>
                )}
                
                <Paper elevation={2} sx={{ p: 2, mb: 2, bgcolor: 'background.default' }}>
                  <Typography variant="subtitle1" gutterBottom>
                    Add New Individual Rock
                  </Typography>
                  
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        name="rock_description"
                        label="Rock Description"
                        value={newIndividualRock.rock_description}
                        onChange={handleNewIndividualRockChange}
                        variant="outlined"
                        size="small"
                        placeholder="e.g., Complete sales training program"
                      />
                    </Grid>
                    
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        name="measurable"
                        label="Measurable"
                        value={newIndividualRock.measurable}
                        onChange={handleNewIndividualRockChange}
                        variant="outlined"
                        size="small"
                        placeholder="e.g., Achieve certification by end of quarter"
                      />
                    </Grid>
                    
                    <Grid item xs={12} sm={6}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Owner</InputLabel>
                        <Select
                          name="owner_id"
                          value={newIndividualRock.owner_id}
                          onChange={handleSelectChange}
                          label="Owner"
                          required
                        >
                          <MenuItem value="" disabled>
                            <em>Select an owner</em>
                          </MenuItem>
                          {teamMembers.map((member) => (
                            <MenuItem key={member.id} value={member.id}>
                              {member.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Grid>
                    
                    <Grid item xs={12} sm={6}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Status</InputLabel>
                        <Select
                          name="status"
                          value={newIndividualRock.status}
                          onChange={handleSelectChange}
                          label="Status"
                        >
                          <MenuItem value="on-track">On Track</MenuItem>
                          <MenuItem value="behind">Behind</MenuItem>
                          <MenuItem value="stuck">Stuck</MenuItem>
                          <MenuItem value="completed">Completed</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                    
                    <Grid item xs={12} display="flex" justifyContent="flex-end">
                      <Button
                        startIcon={<AddIcon />}
                        onClick={handleAddIndividualRock}
                        variant="contained"
                        color="primary"
                        disabled={!quarterlyPlan.id || teamMembers.length === 0}
                      >
                        Add Rock
                      </Button>
                    </Grid>
                  </Grid>
                </Paper>
                
                {!quarterlyPlan.id && (
                  <Alert severity="warning" sx={{ mt: 2 }}>
                    Please save the quarterly plan first before adding rocks.
                  </Alert>
                )}
                
                {teamMembers.length === 0 && (
                  <Alert severity="warning" sx={{ mt: 2 }}>
                    Please add team members to your company before adding individual rocks.
                  </Alert>
                )}
              </TabPanel>
            </Paper>
            
            <Box mt={4} display="flex" justifyContent="space-between">
              <Button
                variant="outlined"
                onClick={() => navigate(`/companies/${companyId}/vision/one-year-plan`)}
              >
                Back: 1-Year Plan
              </Button>
              
              <Button
                variant="contained"
                color="primary"
                onClick={() => navigate(`/companies/${companyId}/vision`)}
              >
                Complete: Back to Vision Dashboard
              </Button>
            </Box>
          </>
        )}
      </Box>
      
      <Snackbar 
        open={notification.open} 
        autoHideDuration={6000} 
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert onClose={handleCloseNotification} severity={notification.severity as any}>
          {notification.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default QuarterlyRocks;
