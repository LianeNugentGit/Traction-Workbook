import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { visionDb } from '../../lib/supabase';
import { 
  Button, 
  Container, 
  Typography, 
  Box, 
  Grid, 
  TextField, 
  IconButton, 
  Paper,
  Divider,
  Alert,
  Snackbar,
  InputAdornment
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import SaveIcon from '@mui/icons-material/Save';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import AICoachingPanel from '../../components/AICoachingPanel';
import { addYears } from 'date-fns';

const TenYearTarget = () => {
  const { companyId } = useParams<{ companyId: string }>();
  const navigate = useNavigate();
  
  const [tenYearTarget, setTenYearTarget] = useState<any>({
    target_description: '',
    target_date: addYears(new Date(), 10)
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showCoaching, setShowCoaching] = useState(false);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'success' });
  
  useEffect(() => {
    if (companyId) {
      fetchTenYearTarget();
    }
  }, [companyId]);
  
  const fetchTenYearTarget = async () => {
    setLoading(true);
    try {
      const { data, error } = await visionDb.getTenYearTarget(companyId as string);
      
      if (error) {
        if (error.code === 'PGRST116') {
          // No data found, this is fine for a new company
          setTenYearTarget({
            target_description: '',
            target_date: addYears(new Date(), 10)
          });
        } else {
          throw error;
        }
      } else if (data) {
        // Convert target_date string to Date object
        setTenYearTarget({
          ...data,
          target_date: data.target_date ? new Date(data.target_date) : addYears(new Date(), 10)
        });
      }
    } catch (error: any) {
      console.error('Error fetching 10-year target:', error.message);
      setNotification({
        open: true,
        message: 'Failed to load 10-year target. Please try again.',
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };
  
  const handleSaveTenYearTarget = async () => {
    if (!tenYearTarget.target_description.trim()) {
      setNotification({
        open: true,
        message: 'Please enter your 10-year target before saving.',
        severity: 'warning'
      });
      return;
    }
    
    setSaving(true);
    try {
      let result;
      
      if (tenYearTarget.id) {
        // Update existing 10-year target
        result = await visionDb.updateTenYearTarget(tenYearTarget.id, {
          target_description: tenYearTarget.target_description,
          target_date: tenYearTarget.target_date
        });
      } else {
        // Create new 10-year target
        result = await visionDb.createTenYearTarget({
          company_id: companyId,
          target_description: tenYearTarget.target_description,
          target_date: tenYearTarget.target_date
        });
      }
      
      if (result.error) {
        throw result.error;
      }
      
      // Update state with the returned data
      if (result.data && result.data[0]) {
        setTenYearTarget({
          ...result.data[0],
          target_date: result.data[0].target_date ? new Date(result.data[0].target_date) : addYears(new Date(), 10)
        });
      }
      
      setNotification({
        open: true,
        message: '10-year target saved successfully!',
        severity: 'success'
      });
    } catch (error: any) {
      console.error('Error saving 10-year target:', error.message);
      setNotification({
        open: true,
        message: 'Failed to save 10-year target. Please try again.',
        severity: 'error'
      });
    } finally {
      setSaving(false);
    }
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setTenYearTarget({ ...tenYearTarget, [name]: value });
  };
  
  const handleDateChange = (newDate: Date | null) => {
    setTenYearTarget({ ...tenYearTarget, target_date: newDate || addYears(new Date(), 10) });
  };
  
  const handleCloseNotification = () => {
    setNotification({ ...notification, open: false });
  };
  
  return (
    <Container maxWidth="lg">
      <Box my={4}>
        <Typography variant="h4" component="h1" gutterBottom>
          10-Year Target Exercise
          <IconButton 
            color="primary" 
            onClick={() => setShowCoaching(!showCoaching)}
            aria-label="Get AI coaching"
          >
            <HelpOutlineIcon />
          </IconButton>
        </Typography>
        
        <Typography variant="body1" paragraph>
          Your 10-Year Target is a long-range, ambitious goal that serves as a rallying cry for your organization. It should be clear, compelling, and emotionally charged.
        </Typography>
        
        {showCoaching && (
          <AICoachingPanel 
            component="Vision" 
            exercise="10-Year Target" 
            onClose={() => setShowCoaching(false)}
          />
        )}
        
        <Divider sx={{ my: 3 }} />
        
        {loading ? (
          <Box display="flex" justifyContent="center" my={4}>
            <Typography>Loading 10-year target...</Typography>
          </Box>
        ) : (
          <>
            <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    Your 10-Year Target
                  </Typography>
                  <Typography variant="body2" color="text.secondary" paragraph>
                    What is your organization's long-range, ambitious goal? What would make you truly proud 10 years from now?
                  </Typography>
                  <TextField
                    fullWidth
                    name="target_description"
                    value={tenYearTarget.target_description || ''}
                    onChange={handleChange}
                    variant="outlined"
                    multiline
                    rows={4}
                    placeholder="e.g., Become the #1 provider in our industry with 100,000 customers worldwide"
                  />
                </Grid>
                
                <Grid item xs={12} md={6}>
                  <Typography variant="h6" gutterBottom>
                    Target Date
                  </Typography>
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DatePicker
                      label="Target Date"
                      value={tenYearTarget.target_date}
                      onChange={handleDateChange}
                      slotProps={{
                        textField: {
                          fullWidth: true,
                          variant: 'outlined'
                        }
                      }}
                    />
                  </LocalizationProvider>
                </Grid>
                
                <Grid item xs={12} display="flex" justifyContent="flex-end">
                  <Button
                    startIcon={<SaveIcon />}
                    onClick={handleSaveTenYearTarget}
                    variant="contained"
                    color="primary"
                    disabled={saving}
                  >
                    {saving ? 'Saving...' : 'Save 10-Year Target'}
                  </Button>
                </Grid>
              </Grid>
            </Paper>
            
            <Box mt={4} display="flex" justifyContent="space-between">
              <Button
                variant="outlined"
                onClick={() => navigate(`/companies/${companyId}/vision/core-focus`)}
              >
                Back: Core Focus
              </Button>
              
              <Button
                variant="contained"
                color="primary"
                onClick={() => navigate(`/companies/${companyId}/vision/marketing-strategy`)}
              >
                Next: Marketing Strategy
              </Button>
            </Box>
          </>
        )}
      </Box>
      
      <Snackbar 
        open={notification.open} 
        autoHideDuration={6000} 
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert onClose={handleCloseNotification} severity={notification.severity as any}>
          {notification.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default TenYearTarget;
