import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { visionDb } from '../../lib/supabase';
import { 
  Button, 
  Card, 
  CardContent, 
  Container, 
  Typography, 
  Box, 
  Grid, 
  TextField, 
  IconButton, 
  Paper,
  Divider,
  Alert,
  Snackbar
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import SaveIcon from '@mui/icons-material/Save';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import AICoachingPanel from '../../components/AICoachingPanel';

const CoreValues = () => {
  const { companyId } = useParams<{ companyId: string }>();
  const navigate = useNavigate();
  
  const [coreValues, setCoreValues] = useState<any[]>([]);
  const [newValue, setNewValue] = useState({ value_name: '', description: '', behaviors: [''] });
  const [loading, setLoading] = useState(true);
  const [showCoaching, setShowCoaching] = useState(false);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'success' });
  
  useEffect(() => {
    if (companyId) {
      fetchCoreValues();
    }
  }, [companyId]);
  
  const fetchCoreValues = async () => {
    setLoading(true);
    try {
      const { data, error } = await visionDb.getCoreValues(companyId as string);
      
      if (error) {
        throw error;
      }
      
      setCoreValues(data || []);
    } catch (error: any) {
      console.error('Error fetching core values:', error.message);
      setNotification({
        open: true,
        message: 'Failed to load core values. Please try again.',
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };
  
  const handleAddCoreValue = async () => {
    if (!newValue.value_name.trim()) {
      setNotification({
        open: true,
        message: 'Core value name is required',
        severity: 'warning'
      });
      return;
    }
    
    try {
      const coreValue = {
        company_id: companyId,
        value_name: newValue.value_name,
        description: newValue.description,
        behaviors: newValue.behaviors.filter(b => b.trim() !== ''),
        order_num: coreValues.length + 1
      };
      
      const { data, error } = await visionDb.createCoreValue(coreValue);
      
      if (error) {
        throw error;
      }
      
      setCoreValues([...coreValues, data[0]]);
      setNewValue({ value_name: '', description: '', behaviors: [''] });
      
      setNotification({
        open: true,
        message: 'Core value added successfully!',
        severity: 'success'
      });
    } catch (error: any) {
      console.error('Error adding core value:', error.message);
      setNotification({
        open: true,
        message: 'Failed to add core value. Please try again.',
        severity: 'error'
      });
    }
  };
  
  const handleDeleteCoreValue = async (id: string) => {
    try {
      const { error } = await visionDb.deleteCoreValue(id);
      
      if (error) {
        throw error;
      }
      
      // Remove the deleted core value
      const updatedCoreValues = coreValues.filter(cv => cv.id !== id);
      
      // Update order_num for remaining core values
      const reorderedCoreValues = updatedCoreValues.map((cv, index) => ({
        ...cv,
        order_num: index + 1
      }));
      
      // Update each core value with new order_num
      for (const cv of reorderedCoreValues) {
        await visionDb.updateCoreValue(cv.id, { order_num: cv.order_num });
      }
      
      setCoreValues(reorderedCoreValues);
      
      setNotification({
        open: true,
        message: 'Core value deleted successfully!',
        severity: 'success'
      });
    } catch (error: any) {
      console.error('Error deleting core value:', error.message);
      setNotification({
        open: true,
        message: 'Failed to delete core value. Please try again.',
        severity: 'error'
      });
    }
  };
  
  const handleMoveUp = async (index: number) => {
    if (index <= 0) return;
    
    try {
      const newCoreValues = [...coreValues];
      const temp = newCoreValues[index];
      newCoreValues[index] = newCoreValues[index - 1];
      newCoreValues[index - 1] = temp;
      
      // Update order_num for the two affected core values
      await visionDb.updateCoreValue(newCoreValues[index].id, { order_num: index + 1 });
      await visionDb.updateCoreValue(newCoreValues[index - 1].id, { order_num: index });
      
      // Update the state
      setCoreValues(newCoreValues);
    } catch (error: any) {
      console.error('Error moving core value:', error.message);
      setNotification({
        open: true,
        message: 'Failed to reorder core values. Please try again.',
        severity: 'error'
      });
    }
  };
  
  const handleMoveDown = async (index: number) => {
    if (index >= coreValues.length - 1) return;
    
    try {
      const newCoreValues = [...coreValues];
      const temp = newCoreValues[index];
      newCoreValues[index] = newCoreValues[index + 1];
      newCoreValues[index + 1] = temp;
      
      // Update order_num for the two affected core values
      await visionDb.updateCoreValue(newCoreValues[index].id, { order_num: index + 1 });
      await visionDb.updateCoreValue(newCoreValues[index + 1].id, { order_num: index + 2 });
      
      // Update the state
      setCoreValues(newCoreValues);
    } catch (error: any) {
      console.error('Error moving core value:', error.message);
      setNotification({
        open: true,
        message: 'Failed to reorder core values. Please try again.',
        severity: 'error'
      });
    }
  };
  
  const handleUpdateCoreValue = async (id: string, updates: any) => {
    try {
      const { error } = await visionDb.updateCoreValue(id, updates);
      
      if (error) {
        throw error;
      }
      
      // Update the state
      setCoreValues(coreValues.map(cv => cv.id === id ? { ...cv, ...updates } : cv));
      
      setNotification({
        open: true,
        message: 'Core value updated successfully!',
        severity: 'success'
      });
    } catch (error: any) {
      console.error('Error updating core value:', error.message);
      setNotification({
        open: true,
        message: 'Failed to update core value. Please try again.',
        severity: 'error'
      });
    }
  };
  
  const handleAddBehavior = (index: number) => {
    const updatedCoreValues = [...coreValues];
    const behaviors = [...updatedCoreValues[index].behaviors, ''];
    updatedCoreValues[index] = { ...updatedCoreValues[index], behaviors };
    setCoreValues(updatedCoreValues);
  };
  
  const handleUpdateBehavior = (valueIndex: number, behaviorIndex: number, text: string) => {
    const updatedCoreValues = [...coreValues];
    const behaviors = [...updatedCoreValues[valueIndex].behaviors];
    behaviors[behaviorIndex] = text;
    updatedCoreValues[valueIndex] = { ...updatedCoreValues[valueIndex], behaviors };
    setCoreValues(updatedCoreValues);
  };
  
  const handleDeleteBehavior = (valueIndex: number, behaviorIndex: number) => {
    const updatedCoreValues = [...coreValues];
    const behaviors = updatedCoreValues[valueIndex].behaviors.filter((_: any, i: number) => i !== behaviorIndex);
    updatedCoreValues[valueIndex] = { ...updatedCoreValues[valueIndex], behaviors };
    setCoreValues(updatedCoreValues);
  };
  
  const handleAddNewBehavior = () => {
    setNewValue({ ...newValue, behaviors: [...newValue.behaviors, ''] });
  };
  
  const handleUpdateNewBehavior = (index: number, text: string) => {
    const behaviors = [...newValue.behaviors];
    behaviors[index] = text;
    setNewValue({ ...newValue, behaviors });
  };
  
  const handleDeleteNewBehavior = (index: number) => {
    const behaviors = newValue.behaviors.filter((_: any, i: number) => i !== index);
    setNewValue({ ...newValue, behaviors });
  };
  
  const handleSaveCoreValue = async (index: number) => {
    const coreValue = coreValues[index];
    
    // Filter out empty behaviors
    const behaviors = coreValue.behaviors.filter((b: string) => b.trim() !== '');
    
    try {
      const { error } = await visionDb.updateCoreValue(coreValue.id, { 
        value_name: coreValue.value_name,
        description: coreValue.description,
        behaviors
      });
      
      if (error) {
        throw error;
      }
      
      // Update the state
      const updatedCoreValues = [...coreValues];
      updatedCoreValues[index] = { ...updatedCoreValues[index], behaviors };
      setCoreValues(updatedCoreValues);
      
      setNotification({
        open: true,
        message: 'Core value updated successfully!',
        severity: 'success'
      });
    } catch (error: any) {
      console.error('Error updating core value:', error.message);
      setNotification({
        open: true,
        message: 'Failed to update core value. Please try again.',
        severity: 'error'
      });
    }
  };
  
  const handleCloseNotification = () => {
    setNotification({ ...notification, open: false });
  };
  
  return (
    <Container maxWidth="lg">
      <Box my={4}>
        <Typography variant="h4" component="h1" gutterBottom>
          Core Values Exercise
          <IconButton 
            color="primary" 
            onClick={() => setShowCoaching(!showCoaching)}
            aria-label="Get AI coaching"
          >
            <HelpOutlineIcon />
          </IconButton>
        </Typography>
        
        <Typography variant="body1" paragraph>
          Core Values are the essential and enduring tenets of your organization. They're a small set of guiding principles that have a profound impact on how everyone in the organization thinks and acts.
        </Typography>
        
        {showCoaching && (
          <AICoachingPanel 
            component="Vision" 
            exercise="Core Values" 
            onClose={() => setShowCoaching(false)}
          />
        )}
        
        <Divider sx={{ my: 3 }} />
        
        {loading ? (
          <Box display="flex" justifyContent="center" my={4}>
            <Typography>Loading core values...</Typography>
          </Box>
        ) : (
          <>
            {coreValues.length > 0 ? (
              <Box mb={4}>
                <Typography variant="h5" gutterBottom>
                  Your Core Values
                </Typography>
                
                {coreValues.map((coreValue, index) => (
                  <Paper 
                    key={coreValue.id} 
                    elevation={3} 
                    sx={{ p: 3, mb: 3 }}
                  >
                    <Grid container spacing={2}>
                      <Grid item xs={12} display="flex" justifyContent="space-between" alignItems="center">
                        <Box display="flex" alignItems="center">
                          <Typography variant="h6" component="span" sx={{ mr: 2 }}>
                            {index + 1}.
                          </Typography>
                          <TextField
                            fullWidth
                            label="Core Value"
                            value={coreValue.value_name}
                            onChange={(e) => {
                              const updatedCoreValues = [...coreValues];
                              updatedCoreValues[index] = { ...updatedCoreValues[index], value_name: e.target.value };
                              setCoreValues(updatedCoreValues);
                            }}
                            variant="outlined"
                            sx={{ mr: 2 }}
                          />
                        </Box>
                        
                        <Box>
                          <IconButton 
                            onClick={() => handleMoveUp(index)}
                            disabled={index === 0}
                            size="small"
                          >
                            <ArrowUpwardIcon />
                          </IconButton>
                          <IconButton 
                            onClick={() => handleMoveDown(index)}
                            disabled={index === coreValues.length - 1}
                            size="small"
                          >
                            <ArrowDownwardIcon />
                          </IconButton>
                          <IconButton 
                            onClick={() => handleDeleteCoreValue(coreValue.id)}
                            color="error"
                            size="small"
                          >
                            <DeleteIcon />
                          </IconButton>
                        </Box>
                      </Grid>
                      
                      <Grid item xs={12}>
                        <TextField
                          fullWidth
                          label="Description"
                          value={coreValue.description || ''}
                          onChange={(e) => {
                            const updatedCoreValues = [...coreValues];
                            updatedCoreValues[index] = { ...updatedCoreValues[index], description: e.target.value };
                            setCoreValues(updatedCoreValues);
                          }}
                          variant="outlined"
                          multiline
                          rows={2}
                        />
                      </Grid>
                      
                      <Grid item xs={12}>
                        <Typography variant="subtitle1" gutterBottom>
                          Behaviors
                        </Typography>
                        
                        {coreValue.behaviors && coreValue.behaviors.map((behavior: string, behaviorIndex: number) => (
                          <Box key={behaviorIndex} display="flex" alignItems="center" mb={1}>
                            <TextField
                              fullWidth
                              label={`Behavior ${behaviorIndex + 1}`}
                              value={behavior}
                              onChange={(e) => handleUpdateBehavior(index, behaviorIndex, e.target.value)}
                              variant="outlined"
                              sx={{ mr: 1 }}
                            />
                            <IconButton 
                              onClick={() => handleDeleteBehavior(index, behaviorIndex)}
                              color="error"
                              size="small"
                            >
                              <DeleteIcon />
                            </IconButton>
                          </Box>
                        ))}
                        
                        <Button
                          startIcon={<AddIcon />}
                          onClick={() => handleAddBehavior(index)}
                          variant="outlined"
                          size="small"
                          sx={{ mt: 1 }}
                        >
                          Add Behavior
                        </Button>
                      </Grid>
                      
                      <Grid item xs={12} display="flex" justifyContent="flex-end">
                        <Button
                          startIcon={<SaveIcon />}
                          onClick={() => handleSaveCoreValue(index)}
                          variant="contained"
                          color="primary"
                        >
                          Save Changes
                        </Button>
                      </Grid>
                    </Grid>
                  </Paper>
                ))}
              </Box>
            ) : (
              <Box mb={4}>
                <Alert severity="info" sx={{ mb: 3 }}>
                  You haven't defined any Core Values yet. Start by adding your first Core Value below.
                </Alert>
              </Box>
            )}
            
            <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
              <Typography variant="h5" gutterBottom>
                Add New Core Value
              </Typography>
              
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Core Value"
                    value={newValue.value_name}
                    onChange={(e) => setNewValue({ ...newValue, value_name: e.target.value })}
                    variant="outlined"
                    placeholder="e.g., Integrity, Innovation, Customer Focus"
                  />
                </Grid>
                
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Description"
                    value={newValue.description}
                    onChange={(e) => setNewValue({ ...newValue, description: e.target.value })}
                    variant="outlined"
                    multiline
                    rows={2}
                    placeholder="Describe what this core value means to your organization"
                  />
                </Grid>
                
                <Grid item xs={12}>
                  <Typography variant="subtitle1" gutterBottom>
                    Behaviors
                  </Typography>
                  
                  {newValue.behaviors.map((behavior, index) => (
                    <Box key={index} display="flex" alignItems="center" mb={1}>
                      <TextField
                        fullWidth
                        label={`Behavior ${index + 1}`}
                        value={behavior}
                        onChange={(e) => handleUpdateNewBehavior(index, e.target.value)}
                        variant="outlined"
                        placeholder="Describe a specific behavior that demonstrates this value"
                        sx={{ mr: 1 }}
                      />
                      <IconButton 
                        onClick={() => handleDeleteNewBehavior(index)}
                        color="error"
                        size="small"
                        disabled={index === 0 && newValue.behaviors.length === 1}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Box>
                  ))}
                  
                  <Button
                    startIcon={<AddIcon />}
                    onClick={handleAddNewBehavior}
                    variant="outlined"
                    size="small"
                    sx={{ mt: 1 }}
                  >
                    Add Behavior
                  </Button>
                </Grid>
                
                <Grid item xs={12} display="flex" justifyContent="flex-end">
                  <Button
                    startIcon={<AddIcon />}
                    onClick={handleAddCoreValue}
                    variant="contained"
                    color="primary"
                    size="large"
                  >
                    Add Core Value
                  </Button>
                </Grid>
              </Grid>
            </Paper>
            
            <Box mt={4} display="flex" justifyContent="space-between">
              <Button
                variant="outlined"
                onClick={() => navigate(`/companies/${companyId}/vision`)}
              >
                Back to Vision Dashboard
              </Button>
              
              <Button
                variant="contained"
                color="primary"
                onClick={() => navigate(`/companies/${companyId}/vision/core-focus`)}
              >
                Next: Core Focus
              </Button>
            </Box>
          </>
        )}
      </Box>
      
      <Snackbar 
        open={notification.open} 
        autoHideDuration={6000} 
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert onClose={handleCloseNotification} severity={notification.severity as any}>
          {notification.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default CoreValues;
