import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { visionDb } from '../../lib/supabase';
import { 
  Button, 
  Container, 
  Typography, 
  Box, 
  Grid, 
  TextField, 
  IconButton, 
  Paper,
  Divider,
  Alert,
  Snackbar,
  Chip,
  Stack
} from '@mui/material';
import SaveIcon from '@mui/icons-material/Save';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import AICoachingPanel from '../../components/AICoachingPanel';

const MarketingStrategy = () => {
  const { companyId } = useParams<{ companyId: string }>();
  const navigate = useNavigate();
  
  const [marketingStrategy, setMarketingStrategy] = useState<any>({
    target_market: '',
    uniques: ['', '', ''],
    proven_process: '',
    guarantee: ''
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showCoaching, setShowCoaching] = useState(false);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'success' });
  
  useEffect(() => {
    if (companyId) {
      fetchMarketingStrategy();
    }
  }, [companyId]);
  
  const fetchMarketingStrategy = async () => {
    setLoading(true);
    try {
      const { data, error } = await visionDb.getMarketingStrategy(companyId as string);
      
      if (error) {
        if (error.code === 'PGRST116') {
          // No data found, this is fine for a new company
          setMarketingStrategy({
            target_market: '',
            uniques: ['', '', ''],
            proven_process: '',
            guarantee: ''
          });
        } else {
          throw error;
        }
      } else if (data) {
        // Ensure uniques is an array with at least 3 items
        const uniques = Array.isArray(data.uniques) ? data.uniques : [];
        while (uniques.length < 3) {
          uniques.push('');
        }
        
        setMarketingStrategy({
          ...data,
          uniques
        });
      }
    } catch (error: any) {
      console.error('Error fetching marketing strategy:', error.message);
      setNotification({
        open: true,
        message: 'Failed to load marketing strategy. Please try again.',
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };
  
  const handleSaveMarketingStrategy = async () => {
    if (!marketingStrategy.target_market.trim()) {
      setNotification({
        open: true,
        message: 'Please define your target market before saving.',
        severity: 'warning'
      });
      return;
    }
    
    // Filter out empty uniques
    const uniques = marketingStrategy.uniques.filter((unique: string) => unique.trim() !== '');
    
    if (uniques.length === 0) {
      setNotification({
        open: true,
        message: 'Please define at least one unique before saving.',
        severity: 'warning'
      });
      return;
    }
    
    setSaving(true);
    try {
      let result;
      
      if (marketingStrategy.id) {
        // Update existing marketing strategy
        result = await visionDb.updateMarketingStrategy(marketingStrategy.id, {
          target_market: marketingStrategy.target_market,
          uniques,
          proven_process: marketingStrategy.proven_process,
          guarantee: marketingStrategy.guarantee
        });
      } else {
        // Create new marketing strategy
        result = await visionDb.createMarketingStrategy({
          company_id: companyId,
          target_market: marketingStrategy.target_market,
          uniques,
          proven_process: marketingStrategy.proven_process,
          guarantee: marketingStrategy.guarantee
        });
      }
      
      if (result.error) {
        throw result.error;
      }
      
      // Update state with the returned data
      if (result.data && result.data[0]) {
        // Ensure uniques is an array with at least 3 items
        const updatedUniques = Array.isArray(result.data[0].uniques) ? result.data[0].uniques : [];
        while (updatedUniques.length < 3) {
          updatedUniques.push('');
        }
        
        setMarketingStrategy({
          ...result.data[0],
          uniques: updatedUniques
        });
      }
      
      setNotification({
        open: true,
        message: 'Marketing strategy saved successfully!',
        severity: 'success'
      });
    } catch (error: any) {
      console.error('Error saving marketing strategy:', error.message);
      setNotification({
        open: true,
        message: 'Failed to save marketing strategy. Please try again.',
        severity: 'error'
      });
    } finally {
      setSaving(false);
    }
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setMarketingStrategy({ ...marketingStrategy, [name]: value });
  };
  
  const handleUniqueChange = (index: number, value: string) => {
    const uniques = [...marketingStrategy.uniques];
    uniques[index] = value;
    setMarketingStrategy({ ...marketingStrategy, uniques });
  };
  
  const handleAddUnique = () => {
    const uniques = [...marketingStrategy.uniques, ''];
    setMarketingStrategy({ ...marketingStrategy, uniques });
  };
  
  const handleRemoveUnique = (index: number) => {
    const uniques = marketingStrategy.uniques.filter((_: string, i: number) => i !== index);
    setMarketingStrategy({ ...marketingStrategy, uniques });
  };
  
  const handleCloseNotification = () => {
    setNotification({ ...notification, open: false });
  };
  
  return (
    <Container maxWidth="lg">
      <Box my={4}>
        <Typography variant="h4" component="h1" gutterBottom>
          Marketing Strategy Exercise
          <IconButton 
            color="primary" 
            onClick={() => setShowCoaching(!showCoaching)}
            aria-label="Get AI coaching"
          >
            <HelpOutlineIcon />
          </IconButton>
        </Typography>
        
        <Typography variant="body1" paragraph>
          Your Marketing Strategy consists of your Target Market (who your ideal customer is), your Three Uniques (what makes you different), your Proven Process (how you deliver), and your Guarantee (what you promise).
        </Typography>
        
        {showCoaching && (
          <AICoachingPanel 
            component="Vision" 
            exercise="Marketing Strategy" 
            onClose={() => setShowCoaching(false)}
          />
        )}
        
        <Divider sx={{ my: 3 }} />
        
        {loading ? (
          <Box display="flex" justifyContent="center" my={4}>
            <Typography>Loading marketing strategy...</Typography>
          </Box>
        ) : (
          <>
            <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    Target Market
                  </Typography>
                  <Typography variant="body2" color="text.secondary" paragraph>
                    Who is your ideal customer? Be as specific as possible.
                  </Typography>
                  <TextField
                    fullWidth
                    name="target_market"
                    value={marketingStrategy.target_market || ''}
                    onChange={handleChange}
                    variant="outlined"
                    multiline
                    rows={3}
                    placeholder="e.g., Small to medium businesses (10-250 employees) in service industries"
                  />
                </Grid>
                
                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    Three Uniques
                  </Typography>
                  <Typography variant="body2" color="text.secondary" paragraph>
                    What makes you different from your competitors? What combination of attributes makes you unique in the marketplace?
                  </Typography>
                  
                  {marketingStrategy.uniques.map((unique: string, index: number) => (
                    <Box key={index} display="flex" alignItems="center" mb={2}>
                      <Typography variant="body2" sx={{ mr: 2, minWidth: '80px' }}>
                        Unique {index + 1}:
                      </Typography>
                      <TextField
                        fullWidth
                        value={unique}
                        onChange={(e) => handleUniqueChange(index, e.target.value)}
                        variant="outlined"
                        placeholder={`e.g., ${index === 0 ? '24/7 live customer support' : index === 1 ? 'No-questions-asked returns' : 'Lifetime warranty'}`}
                        sx={{ mr: 1 }}
                      />
                      <IconButton 
                        onClick={() => handleRemoveUnique(index)}
                        color="error"
                        size="small"
                        disabled={marketingStrategy.uniques.length <= 1}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Box>
                  ))}
                  
                  <Button
                    startIcon={<AddIcon />}
                    onClick={handleAddUnique}
                    variant="outlined"
                    size="small"
                    sx={{ mt: 1 }}
                  >
                    Add Another Unique
                  </Button>
                </Grid>
                
                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    Proven Process
                  </Typography>
                  <Typography variant="body2" color="text.secondary" paragraph>
                    How do you deliver your product or service? What are the steps in your process?
                  </Typography>
                  <TextField
                    fullWidth
                    name="proven_process"
                    value={marketingStrategy.proven_process || ''}
                    onChange={handleChange}
                    variant="outlined"
                    multiline
                    rows={3}
                    placeholder="e.g., 1. Discovery consultation, 2. Custom implementation, 3. Team training, 4. Ongoing support"
                  />
                </Grid>
                
                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    Guarantee
                  </Typography>
                  <Typography variant="body2" color="text.secondary" paragraph>
                    What do you promise your customers? What guarantee do you offer?
                  </Typography>
                  <TextField
                    fullWidth
                    name="guarantee"
                    value={marketingStrategy.guarantee || ''}
                    onChange={handleChange}
                    variant="outlined"
                    multiline
                    rows={2}
                    placeholder="e.g., 100% satisfaction or your money back for the first 90 days"
                  />
                </Grid>
                
                <Grid item xs={12} display="flex" justifyContent="flex-end">
                  <Button
                    startIcon={<SaveIcon />}
                    onClick={handleSaveMarketingStrategy}
                    variant="contained"
                    color="primary"
                    disabled={saving}
                  >
                    {saving ? 'Saving...' : 'Save Marketing Strategy'}
                  </Button>
                </Grid>
              </Grid>
            </Paper>
            
            <Box mt={4} display="flex" justifyContent="space-between">
              <Button
                variant="outlined"
                onClick={() => navigate(`/companies/${companyId}/vision/ten-year-target`)}
              >
                Back: 10-Year Target
              </Button>
              
              <Button
                variant="contained"
                color="primary"
                onClick={() => navigate(`/companies/${companyId}/vision/three-year-picture`)}
              >
                Next: 3-Year Picture
              </Button>
            </Box>
          </>
        )}
      </Box>
      
      <Snackbar 
        open={notification.open} 
        autoHideDuration={6000} 
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert onClose={handleCloseNotification} severity={notification.severity as any}>
          {notification.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default MarketingStrategy;
